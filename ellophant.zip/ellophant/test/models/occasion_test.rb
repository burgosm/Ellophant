require 'test_helper'

class OccasionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
