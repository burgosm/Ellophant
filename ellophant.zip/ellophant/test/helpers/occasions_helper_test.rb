require 'test_helper'

class OccasionsHelperTest < ActionView::TestCase
end
