require 'test_helper'

class LandingsHelperTest < ActionView::TestCase
end
