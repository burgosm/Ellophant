require 'test_helper'

class CardsHelperTest < ActionView::TestCase
end
