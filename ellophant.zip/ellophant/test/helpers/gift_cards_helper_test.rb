require 'test_helper'

class GiftCardsHelperTest < ActionView::TestCase
end
