require 'test_helper'

class CardsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
