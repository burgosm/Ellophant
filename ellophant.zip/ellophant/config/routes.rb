Rails.application.routes.draw do
  get 'occasions/index'

  get 'occasions/new'

  get 'occasions/update'

  get 'occasions/delete'

  get 'occasions/create'

  resources :gift_cards do
    collection do
      post :import
    end
  end

  devise_for :users #, controllers: { sessions: 'users/sessions' }
  resources :users
  
  root to: 'landings#index'
  
  get '/contact', to: 'landings#contact'
  
  
  get '/dashboard', to: 'dashboards#index'
  post '/dashboard', to: 'dashboards#index'
  match "/contacts/gmail/callback" => "dashboards#index", via: [:get]#, redirect_to: '/dashboard'
  match "/contacts/hotmail/callback" => "dashboards#index", via: [:get]
  match "/contacts/outlook/callback" => "dashboards#index", via: [:get]
  match "/contacts/facebook/callback" => "dashboards#index", via: [:get]
  match "/callback" => "dashboards#index", via: [:get] #yahoo
  match '/contacts/failure' => "dashboards#failure", via: [:get]
  
  match "dashboards/create_card", to: "dashboards#create_card", via: "post"
  match "dashboards/delete_card", to: "dashboards#delete_card", via: "post"
  
  match "dashboards/process_order", to: "dashboards#process_order", via: "post"
  
  match "dashboards/add_contact", to: "dashboards#add_contact", via: "post"
  match "dashboards/edit_contact", to: "dashboards#edit_contact", via: "post"
  match "dashboards/delete_contact", to: "dashboards#delete_contact", via: "post"
  
  match "dashboards/add_address", to: "dashboards#add_address", via: "post"
  match "dashboards/add_return_address", to: "dashboards#add_return_address", via: "post"
  match "dashboards/add_occasion", to: "dashboards#add_occasion", via: "post"
  
  match "dashboards/add_to_schedule", to: "dashboards#add_to_schedule", via: "post"
  match "dashboards/remove_from_schedule", to: "dashboards#remove_from_schedule", via: "post"
  match "dashboards/remove_from_order", to: "dashboards#remove_from_order", via: "post"
  
  match "dashboards/get_gift_card_values", to: "dashboards#get_gift_card_values", via: "post"
  
  get "/cards", to: 'cards#index'
  match "/cards", to: "cards#new", via: "post"
  
  get "/orders", to: 'orders#index'
  match "orders/delete_orders", to: "orders#delete_orders", via: "post"
  match "orders/generate_excel_file", to: "orders#generate_excel_file", via: "post"
  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  # root 'welcome#index'

  # Example of regular route:
  #   get 'products/:id' => 'catalog#view'

  # Example of named route that can be invoked with purchase_url(id: product.id)
  #   get 'products/:id/purchase' => 'catalog#purchase', as: :purchase

  # Example resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Example resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Example resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Example resource route with more complex sub-resources:
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', on: :collection
  #     end
  #   end

  # Example resource route with concerns:
  #   concern :toggleable do
  #     post 'toggle'
  #   end
  #   resources :posts, concerns: :toggleable
  #   resources :photos, concerns: :toggleable

  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
end
