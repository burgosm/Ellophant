require "omnicontacts"

Rails.application.middleware.use OmniContacts::Builder do
  importer :gmail, "669002019584-8a9itlg9dhnov1ib49gap7kdl4mdstsi.apps.googleusercontent.com", ENV["GOOGLE_API_CLIENT_SECRET"], {:redirect_path => "/contacts/gmail/callback", :max_results => 1000}
  importer :yahoo, "dj0yJmk9ZWtkYnVZMElHSm9RJmQ9WVdrOU5XcGhXVmxOTm5VbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD02OA--", ENV["YAHOO_API_CLIENT_SECRET"], {:callback_path => "/callback"}
  importer :linkedin, "consumer_id", "consumer_secret", {:redirect_path => "/oauth2callback", :state => '<long_unique_string_value>'}
  importer :hotmail, "b91f090a-f5a6-42c1-864d-83c73e8f7e39", ENV["MICROSOFT_API_CLIENT_SECRET"], {:redirect_path => "/contacts/hotmail/callback" }
  importer :outlook, "b91f090a-f5a6-42c1-864d-83c73e8f7e39", ENV["MICROSOFT_API_CLIENT_SECRET"], {:redirect_path => "/contacts/outlook/callback" }
  importer :facebook, "571932056347739", "4f336deb16550d950fee6a743aeeb25c"

end