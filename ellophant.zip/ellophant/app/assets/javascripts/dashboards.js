function closeContact() {
		$('body').removeClass('noscroll');
		//debugger;
		$('#contact-view').removeClass('fixed');
		var activeContact = $('#contact-view').find('.active-contact');
		setTimeout(function() {
			activeContact.removeClass('active-contact').removeClass('card-view');
			activeContact.find('.active-occasion').removeClass('active-occasion');
		activeContact.find('.tab-list').show();//.find('.hide-tablist');//.removeClass('hide-tablist');
		}, 400);
		
		$('#return-address').removeClass('active-occasion');
		$('#instructions').removeClass('active-occasion');
		$('#credit-card-form').removeClass('active-occasion');
		$('#imported-contacts').removeClass('active-occasion');
	}

function showContact(contact, fromOrders) {
	//console.log('showContact');
	if(contact.hasClass('active-contact')) {
		if(!fromOrders) {
			/*$('.active-contact').removeClass('active-contact');
			$('#contact-view').removeClass('fixed');*/
			closeContact();
		}
		
	}
	else {
		//console.log('showContact else');
		$('.active-contact').removeClass('active-contact');
		contact.addClass('active-contact');
		$('#contact-view').addClass('fixed');
		//console.log('Contact view');
	}
	$('body').toggleClass('noscroll');
	$('#return-address').removeClass('active-occasion');
	$('#instructions').removeClass('active-occasion');
	$('#credit-card-form').removeClass('active-occasion');
	$('#imported-contacts').removeClass('active-occasion');
}
function scrollToContact(contact, fromOrders) {
	//console.log('scrollToContact');
	//console.log(contact);
	showContact(contact, fromOrders);
	/*$('.contact').each(function(event) {
		debugger;
		if($(this).hasClass('active-contact')) {
			return false;
		}
		else {
			$(this).appendTo($("#contacts-list"));
		}
	});
  var scrollPosition = contact.position().top;
	var listPosition = $('#contacts-list').position().top;
  $('#contacts-list').animate({
    scrollTop: 0
  }, 200);*/
	/*$('html, body').animate({
    scrollTop: scrollPosition
  }, 200);*/
}



function scrollToCard(occasion) {
	
		var cards = occasion.find('.cards');
		var activeCard = occasion.find('.active-card');
	var index = activeCard.data('slick-index') || activeCard.data('index') - 1;
		var swipe;
	
		if(activeCard.length > 0) {
			swipe = false;
		}
		else {
			swipe = true;
		}

		if(cards.hasClass('slick-initialized')) {
			cards.slick('slickSetOption', 'swipe', swipe);
		}
		else {
			
			cards.slick({
				initialSlide: index,
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: swipe,
				draggable: false,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]
			});
	}

	if(activeCard.length > 0) {
		//cards.slick('slickFilter', '.active-card');
		//debugger;
			//cards.on('setPosition', function(event) {
					//activeCard.width(activeCard.width()*3);
					//cards.unbind('setPosition');
				//});
		var scrollControls = occasion.find('.slick-arrow');
		scrollControls.hide();
	}
		
		/*
		// necessary when slick infinite = true
		var clonedCard = cards.find('.slick-cloned');
	  clonedCard.removeClass('active-card');
	  clonedCard.find('.card-options').remove();*/
}

function addContact(event) {
	//$('#contacts-list').show();
	var newContactForm = "<div class='contact'><input type='text' class='enter-new-contact' placeholder='Enter Name'></input></div>";
	var firstContact = $('#contacts-list .contact').first();
	
	if(firstContact.length) {
		$(newContactForm).insertBefore(firstContact);
	}
	else {
		$('#contacts-list').append(newContactForm);
	}
	
	if($('.enter-new-contact').first().val() !== "") {
      $('.enter-new-contact').first().blur();
    }
  
    //var contact = $(event.field);
  
    //contact.find('.name').hide();    
    //contact.find('.delete-contact').hide();
    $('.enter-new-contact').show().focus(); 
    
  
    $('.enter-new-contact').on('focusout', function(event) {
			//debugger;
      //$(event.target).hide();
      var name = $(event.target).val();
      if(name === '') {
        $('.enter-new-contact').parent().remove();
      }
      else {
        //contact.find('.name').text(name).prepend('<i class="material-icons arrow">arrow_drop_down</i>').show();
        //contact.find('.details-row').show();
        //$('.contact').removeClass('active-contact');
				//var valuesToSubmit = $('form#edit_user_1').serialize();
				
				
				$.ajax({

						url: '/dashboards/add_contact',
						type: "POST",
						data: {
								name: name
						},
						dataType: "script",
						success: function () {
								$('.enter-new-contact').remove();
						}
				});
        //contact.find('.contact').addClass('active-contact');
				
        //scrollToContact(contact.find('.contact')); //.closest('.contact')
      }
		});
	
	  $('.enter-new-contact').on('keydown', function(event) {
    // if user presses enter button on keyboard
    if(event.keyCode === 13) {
      // remove focus from enter-name input
      $(event.target).blur();
    }
    else {
      return;
    }
  });
}
function formatDate(date) {
	var dateParts = date.split("-");
	var dateArray = new Array();
	var formattedDate = dateParts[1] + "/" + dateParts[2] + "/" + dateParts[0];
	return formattedDate;
	/*for(i=0; i<dateParts.length; i++) {
		dateArray[i] =  
	}*/
}

function addCards(cards, card, open) {

		var cardIndex = card.data('slick-index') + 2;

		var leftInterior = card.clone();
		leftInterior.find('.card-exterior').remove();
		leftInterior.find('.card-interior-right').remove();
		leftInterior.find('.open-card').remove();
		leftInterior.find('.click-to-open').remove();
	  leftInterior.append("<div id='open-card-controls'><div class='left-side active'>Left Side</div><div class='close-card'>Close Card</div><div class='right-side'>Right Side</div></div>");
		leftInterior.find('.card-interior-left').addClass('card-interior').addClass('left').removeClass('card-interior-left');
		leftInterior.removeClass('active-card');

		var leftCardIndex = card.data('slick-index');
		cards.slick('slickAdd', leftInterior, leftCardIndex);

	var rightInterior = card.clone();
		rightInterior.find('.card-exterior').remove();
		rightInterior.find('.card-interior-left').remove();
		rightInterior.find('.open-card').remove();
		rightInterior.find('.click-to-open').remove();
	  rightInterior.append("<div id='open-card-controls'><div class='left-side'>Left Side</div><div class='close-card'>Close Card</div><div class='right-side active'>Right Side</div></div>")
		rightInterior.find('.card-interior-right').addClass('card-interior').addClass('right').removeClass('card-interior-right');
		rightInterior.removeClass('active-card');

		var rightCardIndex = card.data('slick-index') + 1;
		cards.slick('slickAdd', rightInterior, rightCardIndex);
	
	if(open) {
			
			//cards.off('reInit');
			cards.slick('unslick');
			cards.slick({
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: false,
				draggable: false,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]
			});
			cards.slick('slickGoTo', cardIndex, true);
		
			var scrollControls = cards.find('.slick-arrow');
			scrollControls.hide();
		
			var tab = card.parents('.tab');
			
			var rightInterior = tab.find('.card-interior.right');
			var leftInterior = tab.find('.card-interior.left');
			
			rightInterior.css({'margin': '0 auto','margin-right': '0'});
			
			var marginLeftRightInterior = Math.round(parseInt(cards.find('.card-interior.right').css('margin-left'))) + 1;
			var cardImageWidth = Math.round(cards.find('.card-interior.right').width());
			var cardsWidth = Math.round(cards.width());
			var marginLeftLeftInterior = cardsWidth - cardImageWidth + marginLeftRightInterior;
			
			leftInterior.css('margin-left', marginLeftLeftInterior);
			/*setTimeout(function() {
				cards.slick('slickGoTo', cardIndex, true);
			}, 500);*/
			/*cards.on('reInit', function(event, slick) {
				debugger;
				console.log('before slickGoTo');
				console.log(cards);
				console.log(cardIndex);
				console.log(event);
				console.log(slick);
				
				cards.slick('slickGoTo', cardIndex, true);
				console.log('after slickGoTo');
			});	*/
		}
		/*else {
			cards.off('reInit');
		}*/
		
		
	}
	
	function removeCards(cards, card, open) {
		var cardIndex;
		//debugger;
		if(!open) {
			var activeCard = cards.find('.active-card');
			cardIndex = activeCard.data('slick-index') + 1;
		}
		else {
			cardIndex = card.data('slick-index');
		}
		
		var leftSide = card.find('.card-interior.left');
		var goToCard;
		
		if(leftSide.length || !open) {
			
			goToCard = cardIndex - 1;
			//cards.slick('slickGoTo', goToCard, true);
			cards.slick('slickRemove', cardIndex);
			cards.slick('slickRemove', cardIndex).slick('refresh');
			
		}
		else {
			goToCard = cardIndex - 2;
			
			cards.slick('slickRemove', cardIndex);
			cards.slick('slickRemove', cardIndex - 1).slick('refresh');
			
		}
		
			//debugger;
		//cards.off('reInit');
		//console.log("Card: " + goToCard);
		//if(open) {
			cards.slick('unslick');
			cards.slick({
				initialSlide: goToCard,
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: true,
				draggable: false,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]
			});
			//cards.slick('slickGoTo', goToCard, true);
			/*setTimeout(function() {
				cards.slick('slickGoTo', goToCard, true);
			}, 600);*/
		//}
		//cards.slick('slickGoTo', goToCard, true);
	}

$(document).on('ready', function () {
	$('body').css("display", "block");
	
	/*$(window).scroll(function() {
    
		if ($(window).scrollTop() > $('#orders').height() - $(window).height() + 155) {
			if($('#contacts-list').height() > $(window).height()) {
				$('#orders').addClass("fix-orders");
			}
		} else {
			$('#orders').removeClass("fix-orders");
		}
		
		if($('#contacts-list').height() < $(window).height()) {
			$('#contacts-list').addClass('fix-contacts-list');
		}
		else {
			$('#contacts-list').removeClass('fix-contacts-list');
		}

	});*/
		/*$('#contacts-list').scroll(function(event) {
		//debugger;
		var contactPos = $('#contacts-list').offset().top;
		var firstContact = $('.contact').eq(0);
		var firstContactPos = firstContact.offset().top;
		if(firstContactPos < contactPos) {
			$("#contacts-list").append(firstContact);
		}
	});*/
	
	
		$('.cards').on('breakpoint', function(event, slick, breakpoint){
			//console.log(breakpoint);
			/*function debounce(func, wait, immediate) {
    var timeout;
    return function() {
      var context = this, args = arguments;
      var later = function() {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      var callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  };

  var unslickify = debounce(function() {
      $('.slick-slider').slick('slickUnfilter');
      //$('.slick-slider').slick('unslick');
  }, 250);

	 if(breakpoint === 480) {
    unslickify();
  }*/
		});
	// bind geocomplete to the address field for each contact
	$('#contact-view .contact').each(function(event) {
		
		var contactId = "#" + $(this).attr('id');
		var street1 = $(contactId).find('.street-1');
		var map = $(contactId).find('.map');
		
		street1.geocomplete({ 
			map: map,
			details: contactId,

		});

	});
	
	function addGeocompleteToReturnAddress() {
		var returnAddress = $('#return-address');
		var street1 = $('#return-address').find('.street-1');
		var street1Val = $('#return-address').find('.street-1').val();
		var street2 = $('#return-address').find('.street-2').val();
		var city = $('#return-address').find('.city').val();
		var state = $('#return-address').find('.state').val();
		var zipCode = $('#return-address').find('.zip-code').val();
		//debugger;
		var defaultAddress = street1Val + " " + street2 + ", " + city + ", " + state + " " + zipCode + ", USA";
		street1.geocomplete({ 
			map: "#return-address-map",
			details: returnAddress,
			mapOptions: {
				location: defaultAddress,
				zoom: 10
			}
		});
	}
	
	addGeocompleteToReturnAddress();		
		
  function stripeResponseHandler(status, response) {

    if (response.error) {
      console.log(response.error);
      //displayCreditCardErrors(response.error);
    } else {
      // response contains id and card, which contains additional card details
      console.log(response);
      $('#token').val(response.id);
      $('form#buy').submit();
     }
  }
  
  // get stripe token
  $(document).on('click', '#add-payment-info', function (e) {	
    		
    		e.preventDefault();
    		
    		//$('#credit-card-form .inline-error').remove();
    		//$('#credit-card-form .error').hide();
    
      		//var validCard = validateCreditCard();
    
      		//var differentBillingAddress = $("#same_address").is(":checked");
    	
    		//if(differentBillingAddress == false) {
    
    			//var validBillingAddress = validateBillingAddress();
    
    		//}
    		//else {
    			//validBillingAddress = true;
    		//}
    
    		//if(validCard && validBillingAddress) {
    
    		  	//$('#cc-number, #cc-name').css('border', '1px solid #A9A9A9');
    		  	//$('#ex-cvv, #cc-ex-month, #cc-ex-year').css('border', 'none');
    
    		  	//$('#cc-number, #cc-name, #ex-cvv, #cc-ex-month, #cc-ex-year').unbind();
    		  	
    		  	//var title = $('.currentStep').find('.title').text();
    			//$('.currentStep').find('.title').html("<i class='fa fa-spin fa-spinner fa-pulse'></i>" + title);
    			//$('#cc-submit').html("<i class='fa fa-spin fa-spinner fa-pulse white'></i>");
    
    			//if($('#buy').length) {
    
    				Stripe.card.createToken($('#buy'), stripeResponseHandler);
    			//}
    			//else {
    				//Stripe.card.createToken($('#sell'), stripeResponseHandler);
    			//}
    	  	//}
    	  	
    	});

  // prevent pinch-to-zoom for iOS 10
  /*document.documentElement.addEventListener('touchstart', function (event) {
    if (event.touches.length > 1) {
      event.preventDefault();
    }
  }, false);

  // prevent double tap to zoom for iOS 10
  var lastTouchEnd = 0;
  document.documentElement.addEventListener('touchend', function (event) {
    var now = (new Date()).getTime();
    if (now - lastTouchEnd <= 300) {
      event.preventDefault();
    }
    lastTouchEnd = now;
  }, false);*/
	
	/*$('#contacts-header').on("click", function(event) {
		$("#contacts-list").toggle(); //.toggleClass('hide');
	});*/
	
	/*$('#schedule-header').on("click", function(event) {
		$("#orders").toggle();//.toggleClass('hide');
	});*/
  
  $("#payment-info-header").on('click', function(event) {
		$('#return-address').removeClass('active-occasion');
		$('#instructions').removeClass('active-occasion');
		$('#imported-contacts').removeClass('active-occasion');
    $('#contact-view').addClass('fixed');
		$('#contact-view').find('.active-contact').removeClass('active-contact');
		$('#credit-card-form').addClass('active-occasion');
  });
	
	$('#past-orders-header').on('click', function(event) {
		$('#past-orders-list').toggle();
	});
	
	$('#pending-orders-header').on('click', function(event) {
		$('#pending-orders-list').toggle();
	});
	
	$('#return-address-header').on('click', function(event) {
		$('#credit-card-form').removeClass('active-occasion');
		$('#instructions').removeClass('active-occasion');
		$('#imported-contacts').removeClass('active-occasion');
		$('#contact-view').find('.active-contact').removeClass('active-contact');
		$('#contact-view').addClass('fixed');
		$('#return-address').addClass('active-occasion');
	});
  
  $('body').on('click', '#delete-card-button', function(event) {
    
		// if an ajax request is underway prevent user from creating another
		if(!$(event.currentTarget).hasClass('submitting')) {
			// set flag that ajax request is underway
			$(event.currentTarget).addClass('submitting');
			$.ajax({
					url: 'dashboards/delete_card',
					type: "POST",
					data: {
							delete_card: true
					},
					dataType: "script",
					success: function () {
						// remove flag that ajax request is underway
						$(event.currentTarget).removeClass('submitting');
					}
			});
		}
    
  });
  
  // when the user clicks the "Back" button
  $('body').on('click', '#contact-view .back', function(event) {
  //$('.back').on('click', function(event) {
		//debugger;
		var contact = $(event.currentTarget).parents('.contact');
    var occasion = contact.find('.active-occasion');//.hide();
		var tabList = contact.find('.tab-list');
		//debugger;
		//occasion.removeClass('active-occasion');//hide();
    
		//contact.removeClass('card-view');
    
		//debugger;
		var menu = tabList.css('display'); //.hasClass('hide-tablist');
		
		if(menu == 'none') {
			tabList.slideDown( "fast", function() {
				//tabList.removeClass('hide-tablist');
			});
		}
		else {
			tabList.slideUp( "fast", function() {
				//tabList.addClass('hide-tablist');
			});
		}
    //contact.find('.active-tab').removeClass('active-tab');
  });
  
  // when the user changes an address field, change the address shown on contact screen
  $('.address-1 > input, .address-2 > input, .city > input, .state > input, .zip-code > input').on("focusout", function(event) {
    var street1 = $(event.target).parents('.contact').find('.address-1 > input').val();
    var street2 = $(event.target).parents('.contact').find('.address-2 > input').val();
    var city = $(event.target).parents('.contact').find('.city > input').val();
    var state = $(event.target).parents('.contact').find('.state > input').val();
    var zipCode = $(event.target).parents('.contact').find('.zip-code > input').val();
    $(event.target).parents('.contact').find('[data-association="address"]').text(street1 + " " + street2 + "\n" + city + "," + " " + state + " "+ zipCode);
  });

  $('body').on('click', '#add-contact', addContact); 
  
  // when the user clicks on a "tab" (birthday, thanksgiving, christmas, etc.)
  //$('#contacts').on('click', '.tablink', function(event) {
	
	/*$('body').on('mouseover', '#contact-view .show-menu', function(event) {
		var contact = $(event.currentTarget).closest('.contact');
		var activeOccasion = contact.find('.active-occasion');
		
		if(activeOccasion.length > 0) {
			$('#contact-view').find('.tab-list').removeClass('hide-tablist').addClass('border-and-shadow');
		}
	});*/
	
	if('ontouchstart' in document.documentElement) {
		touchDevice = true;
	}
	else {
		touchDevice = false;
	}
	
	if(!touchDevice) {
		
		$('body').on('mouseleave', '#contact-view .tab-list', function(event) {
			//debugger;

			if( ! $(event.toElement).hasClass('contact-details') ) {

				var contact = $(event.currentTarget).closest('.contact');
				var activeOccasion = contact.find('.active-occasion');
				var tabList = contact.find('.tab-list');
				//debugger;
				if(activeOccasion.length > 0) {
					var menu = tabList.css('display');//.hasClass('hide-tablist');
					//debugger;
					if(menu == 'block') {
						tabList.slideUp( "fast", function() {
							//tabList.addClass('hide-tablist');
						});
					}
					else {
						tabList.slideDown( "fast", function() {
							//tabList.removeClass('hide-tablist');
						});
					}

				}

				//$('#contact-view').find('.tab-list').removeClass('border-and-shadow');
			}

		});
		
		$('body').on('mouseover', '#contact-view .iconlink', function(event) {

			var tabName = $(event.currentTarget).data('id');
			var tabList = $(event.currentTarget).closest('.tab-list');
			var tabLink = tabList.find(".tablink[data-id=" + tabName + "]");
			tabLink.addClass('active-tablink');	

		});

		$('body').on('mouseout', '#contact-view .iconlink', function(event) {

			var tabName = $(event.currentTarget).data('id');
			var tabList = $(event.currentTarget).closest('.tab-list');
			var tabLink = tabList.find(".tablink[data-id=" + tabName + "]");
			tabLink.removeClass('active-tablink');	

		});
		
		// when the user hovers over the "Back" button
		$('body').on('mouseover', '#contact-view .back', function(event) {
		//$('.back').on('click', function(event) {
			//debugger;

			var contact = $(event.currentTarget).parents('.contact');
			var occasion = contact.find('.active-occasion');//.hide();
			var tabList = contact.find('.tab-list');
			//debugger;
			//occasion.removeClass('active-occasion');//hide();

			//contact.removeClass('card-view');

			//debugger;
			var menu = tabList.css('display'); //.hasClass('hide-tablist');

			if(menu == 'none') {
				tabList.slideDown( "fast", function() {
					//tabList.removeClass('hide-tablist');
				});
			}
			/*else {
				tabList.slideUp( "fast", function() {
					tabList.addClass('hide-tablist');
				});
			}*/
			//contact.find('.active-tab').removeClass('active-tab');
	
		});
		
		$('body').on('focus', 'input[type=date]', function(event) {
			if(!$(this).is('[readonly]')) {
				$(this).datepicker({
					dateFormat : 'yy-mm-dd'
				});
			}
		});

	}
	else {
		$('input[readonly]').on('touchstart', function(ev) {
			return false;
		});
	}
	
	/*$('#contact-view').on('mouseover', '.tablink', function(event) {
		$(this).toggleClass('grayscale');
	});*/
	
	
	
	
	$('body').on('click', '#contact-view .tablink', function(event) {
    var tabName = $(event.currentTarget).data('id');
		//debugger;
    var tabList = $(event.currentTarget).closest('.tab-list');//.addClass('hide-tablist'); //.css('display', 'none');
		tabList.hide();
		
		var contact = $(event.currentTarget).closest('.contact');
		contact.addClass('card-view');
		var detailsRow = contact.find('.details-row');
		var contactId = contact.data('contact-id');
		var tabs = contact.find('.tab');
		tabs.hide();
		var occasion = contact.find('.' + tabName);
  
    //var contact = $(event.currentTarget).parents('.contact');
    //contact.find('.active-tab').removeClass('active-tab');

    $(event.currentTarget).addClass('active-tab');
		contact.find('.active-occasion').removeClass('active-occasion');
		
		if(occasion.length) {
			
			occasion.addClass('active-occasion');//.show();
			detailsRow.show();
			var activeCard = occasion.find('.active-card');
			if(activeCard.length > 0) {
				//var cardOptions = occasion.find('.card-options').addClass('options-active'); //.detach();
				//activeCard.append(cardOptions);
				occasion.find('.scroll-control').hide();
			}
			scrollToCard(occasion);
		}
		else {
			// if an ajax request is underway prevent user from creating another
			if(!$(event.currentTarget).hasClass('submitting')) {
				// set flag that ajax request is underway
				$(event.currentTarget).addClass('submitting');
				
				detailsRow.append("<div class='wrap''><div class='loading'><div class='bounceball'></div><div class='text'>LOADING</div></div></div>");
				
				$.ajax({
						url: '/dashboards/add_occasion',
						type: "POST",
						data: {
								occasion_name: tabName,
								contact_id: contactId
						},
						dataType: "script",
						success: function () {
							// remove flag that ajax request is underway
							$(event.currentTarget).removeClass('submitting');
							
							detailsRow.find('.wrap').remove();
						}
				});
			}
		}

    //$(event.currentTarget).parents('.contact').find('.' + tabName).css('display', 'block');
    //$(event.currentTarget).parents('.contact').find('.tab-list').hide();
    
    
    
  });
	
	$('body').on('click', '#contact-view .address-display', function(event) {
		var contact = $(event.currentTarget).closest('.contact');
		//$(event.currentTarget).addClass('hide');
		contact.find('.tab-list').hide();//.addClass('hide-tablist');
		contact.find('.address').removeClass('hide');
	});
	
	$('body').on('click', '#contact-view .save-address', function(event) {
		var contact = $(event.currentTarget).closest('.contact');
		var tab = $(event.currentTarget).closest('.tab');
		var contactId = contact.find('.contact-id').val();
		var street1 = tab.closest('.contact').find('.street-1').val();
		var street2 = tab.closest('.contact').find('.street-2').val();
		var city = tab.closest('.contact').find('.city').val();
		var state = tab.closest('.contact').find('.state').val();
		var zipCode = tab.closest('.contact').find('.zip-code').val();
		
		// if an ajax request is underway prevent user from creating another
		if(!$(event.currentTarget).hasClass('submitting')) {
			// set flag that ajax request is underway
			$(event.currentTarget).addClass('submitting');
		
			$.ajax({

					url: '/dashboards/add_address',
					type: "POST",
					data: {
						contact_id: contactId,
						street_1: street1,
						street_2: street2,
						city: city,
						state: state,
						zip_code: zipCode
					},
					dataType: "script",
					success: function () {
						// remove flag that ajax request is underway
						$('.active-contact').find('.save-address').removeClass('submitting');
						$('.active-contact').find('.show-address').removeClass('show-address');
					}
			});
		}
	});
	
	$('body').on('click', '.save-return-address', function(event) {
		var address = $(event.currentTarget).closest('#return-address')
		var addressId = $(event.currentTarget).closest('#return-address').data('return-address');
		var street1 = address.find('.street-1').val();
		var street2 = address.find('.street-2').val();
		var city = address.find('.city').val();
		var state = address.find('.state').val();
		var zipCode = address.find('.zip-code').val();
		//debugger;
		// if an ajax request is underway prevent user from creating another
		if(!$(event.currentTarget).hasClass('submitting')) {
			// set flag that ajax request is underway
			$(event.currentTarget).addClass('submitting');
		
			$.ajax({

					url: '/dashboards/add_return_address',
					type: "POST",
					data: {
						address_id: addressId,
						street_1: street1,
						street_2: street2,
						city: city,
						state: state,
						zip_code: zipCode
					},
					dataType: "json",
					success: function (data) {
						// remove flag that ajax request is underway
						
						if(data.status == 200) {						
							$('.save-return-address').removeClass('submitting');
							$('.save-return-address').text('Update Return Address');
							//$('#return-address-header').text('Return Address').click();
						}
						else {
							alert("Failed to add return address. Try again.");
						}
					}
			});
		}
	});
	
	$('body').on('click', '#contact-view .add-to-schedule', function(event) {
		//debugger;
		var tab = $(event.currentTarget).closest('.tab');
		var contactId = tab.closest('.contact').find('.contact-id').val();
		var occasionId = tab.closest('.occasion').find('.occasion-id').val();
		if(occasionId === undefined) {
			occasionId = "";
		}
		var occasionName = tab.closest('.occasion').find('.occasion-name').val();
		var cardId = tab.find('.card-id').val();
		var date = tab.find('.date input').val();
		
		if(date === "") {
			tab.find('.error-message').remove();
			var addToSchedule = $(this);
			$("<div class='error-message'>You must choose a date.</div>").insertBefore(addToSchedule);
		}
		else {
			var message = tab.find('.personalized-message').val();

			var giftCardProvider = tab.find('.gift-card-provider').val();
			
			var giftCardSKU = tab.find('.occasion_gift_card_sku').val();
			
			if(giftCardProvider !== "" && giftCardSKU === "") {
				tab.find('.occasion_gift_card_sku').addClass('error');
			}
			else {
				
				tab.find('.occasion_gift_card_sku').removeClass('error');

				//debugger;
				//var utf8
				//var _method
				//var authencity_token

				//var params = "contact_id=" + contactId + "&id=" + occasionId + "&name=" + occasionName + "&card_id=" + cardId + "&date=" + date + "&message=" + message + "&gift_card_provider=" + giftCardProvider + "&gift_card_sku=" + giftCardAmount;

				//var valuesToSubmit = $('form#edit_user_1').serialize();

				// if an ajax request is underway prevent user from creating another
				if(!$(event.currentTarget).hasClass('submitting')) {
					// set flag that ajax request is underway
					$(event.currentTarget).addClass('submitting');

					$.ajax({

							url: '/dashboards/add_to_schedule',
							type: "POST",
							data: {
								id: occasionId,
								contact_id: contactId,
								name: occasionName,
								card_id: cardId,
								date: date,
								message: message,
								gift_card_provider: giftCardProvider,
								gift_card_sku: giftCardSKU
							},
							dataType: "script",
							success: function(data) {
								// remove flag that ajax request is underway
								$(event.currentTarget).removeClass('submitting');
							}
					});
				}
			}
		}
	});
	
	// scroll to contact and occasion when card clicked in orders
	$('body').on('click', '#pending-orders .card-box', function(event) {
		
		var card = $(event.currentTarget).closest('.scheduled-card');
		var occasionId = card.data('occasion-id');
		var occasion = $('#occasion-' + occasionId);
		var contact = $('#occasion-' + occasionId).parents('.contact');
		
		contact.addClass('card-view');
		contact.find('.tab').removeClass('active-occasion');
		$('#return-address').removeClass('active-occasion');
		$('#instructions').removeClass('active-occasion');
		$('#credit-card-form').removeClass('active-occasion');
		$('#imported-contacts').removeClass('active-occasion');
		//if(!contact.hasClass('active-contact')) {

			if($(this).children('#add-card').length === 0) {
				
				var activeCard = occasion.find('.active-card');
				if(activeCard.length > 0) {
					//var cardOptions = occasion.find('.card-options').addClass('options-active'); //.detach();
					//activeCard.append(cardOptions);
				}

			}
			occasion.addClass('active-occasion');//.show();

			contact.find('.tab-list').hide();//.addClass('hide-tablist');
			
			scrollToContact(contact, true);
			scrollToCard(occasion);
			
		//}
		
	});
	
	$('body').on('click', '#orders .remove-from-order', function(event) {
		//var contactId = tab.closest('.contact').find('.contact-id').val();
		//var orderId = $(event.currentTarget).closest('.order').attr('order-id');
		//debugger;
		var occasionId = $(event.currentTarget).closest('.scheduled-card').data('occasion-id');
		//var params = "contact_id=" + contactId + "&id=" + occasionId + "&name=" + occasionName + "&card_id=" + cardId + "&date=" + date + "&message=" + message + "&gift_card_provider=" + giftCardProvider + "&gift_card_amount=" + giftCardAmount;
		
  	//var valuesToSubmit = $('form#edit_user_1').serialize();
		
		// if an ajax request is underway prevent user from creating another
		if(!$(event.currentTarget).hasClass('submitting')) {
			// set flag that ajax request is underway
			$(event.currentTarget).addClass('submitting');

			$.ajax({

					url: '/dashboards/remove_from_order',
					type: "POST",
					data: {
						//order_id: orderId,
						occasion_id: occasionId
					},
					dataType: "script",
					success: function () {
						// remove flag that ajax request is underway
						$(event.currentTarget).removeClass('submitting');
						/*tab.closest('.occasion').find('.occasion-id').val("");
						$("<div class='add-to-schedule'>Add to Schedule</div>").insertBefore($(event.target));
						$(event.target).remove();*/
					}
			});
		}
	});
	
	$('body').on('click', '#contact-view .remove-from-schedule', function(event) {
		
		var tab = $(event.currentTarget).closest('.tab');
		var contactId = tab.closest('.contact').find('.contact-id').val();
		var occasionId = tab.find('.occasion-id').val();
		if(occasionId == undefined) {
			occasionId = "";
		}
		var occasionName = tab.closest('.occasion').find('.occasion-name').val();
		var cardId = tab.find('.card-id').val();
		var date = tab.find('.date input').val();
		var message = tab.find('.personalized-message').val();
		var giftCardProvider = tab.find('.gift-card-provider').val();
		var giftCardAmount = tab.find('.gift-card-amount').val();
		//debugger;
		//var utf8
		//var _method
		//var authencity_token
		
		var params = "contact_id=" + contactId + "&id=" + occasionId + "&name=" + occasionName + "&card_id=" + cardId + "&date=" + date + "&message=" + message + "&gift_card_provider=" + giftCardProvider + "&gift_card_amount=" + giftCardAmount;
		
  	//var valuesToSubmit = $('form#edit_user_1').serialize();
		
		// if an ajax request is underway prevent user from creating another
		if(!$(event.currentTarget).hasClass('submitting')) {
			// set flag that ajax request is underway
			$(event.currentTarget).addClass('submitting');

			$.ajax({

					url: '/dashboards/remove_from_schedule',
					type: "POST",
					data: params,
					dataType: "script",
					success: function () {
						// remove flag that ajax request is underway
						$(event.currentTarget).removeClass('submitting');
						/*tab.closest('.occasion').find('.occasion-id').val("");
						$("<div class='add-to-schedule'>Add to Schedule</div>").insertBefore($(event.target));
						$(event.target).remove();*/
					}
			});
		}
	});
	
	$('body').on('mouseenter', '.card-exterior', function(event) {
		$(event.currentTarget).closest('.card').find('.click-to-open').show();
	});
	
	$('body').on('mouseleave', '.card-exterior', function(event) {
		if( ! $(event.toElement).hasClass('click-to-open') ) {
			$(event.currentTarget).closest('.card').find('.click-to-open').hide();
		}
	});
	
	$('body').on('click', '#contacts-list .iconlink', function(event) {

		event.preventDefault();
		
		var occasionName = $(event.currentTarget).data('id');
		var contact = $(event.target).closest('.contact');
		var contactId = contact.data('contact-id');
		var contactInContactView = $('#contact-view').find('#contact-' + contactId);
		
		var occasion = contactInContactView.find('.' + occasionName);
		
		scrollToContact(contactInContactView);
		contactInContactView.find(".tablink[data-id=" + occasionName + "]").click();
		var activeCard = occasion.find('.active-card');
		if(activeCard.length > 0) {
			scrollToCard(occasion);
		}
	});

  // When a name is clicked it gets moved to the top of the viewport
  $('body').on('click', '#contacts-list .name', function(event) {
		//console.log("Clicked on contact name");
		var importedContact = $(event.target).parents('#imported-contacts');
		
		if(importedContact.length == 0) {  
			//console.log('importedContact.length == 0');
			$('#contact-view').addClass('fixed');
			var contact = $(event.target).parents('.contact');
			var contactId = contact.attr('data-contact-id');
			
			var contactInContactView = $('#contact-view').find('#contact-' + contactId);
			//contactInContactView.addClass('active-contact');
			//var name = " for " + contact.find('.name').text();
			//$("#occasions-for").text(name);
			//var detailsRow = contact.find('.details-row');
			//$('#contact-view').append(detailsRow);
			//detailsRow.show();
			//detailsRow.find('.occasion').show();
			//console.log(contactInContactView);
			scrollToContact(contactInContactView);			
		}
    
  });
	
	$('body').on('keydown', function(event) {
			var activeOccasion = $('.active-occasion');
			var activeCard = activeOccasion.find('.active-card');
			// if user presses left arrow on keyboard
			if(event.keyCode === 37 && !activeCard) {
				activeOccasion.find('.cards').slick('slickPrev');
			}
			else {
				return;
			}

	});
	
	$('body').on('keydown', function(event) {
			var activeOccasion = $('.active-occasion');
			var activeCard = activeOccasion.find('.active-card');
			// if user presses left arrow on keyboard
			if(event.keyCode === 39 && !activeCard) {
				activeOccasion.find('.cards').slick('slickNext');
			}
			else {
				return;
			}

	});
	  
	// scroll to contact when user exits personalized message input
 /* $('#contact-view').on('focusout', '.personalized-message', function(event) {
    var contact = $(event.target).closest('.contact');
    scrollToContact(contact);
  });*/
	
	// when the personalized message changes change the button to read "Update Order"
	$('#contact-view').on('keyup', '.personalized-message', function(event) {
		//debugger;
    var contact = $(event.target).closest('.contact');
    var remove = contact.find('.remove-from-schedule');
		if(remove.length > 0) {
			remove.replaceWith("<div class='add-to-schedule'>Update Order</div>");
		}
  });
	
	// when the gift card provider changes change the button to read "Update Order"
	$('#contact-view').on('change', '.gift-card-provider', function(event) {
		//debugger;
		var contact = $(event.target).closest('.contact');
		var activeOccasion = contact.find('.active-occasion');
		//var contactId = contact.find('.contact-id').val();
		var giftCard = $(this).val(); //.children(":selected").attr("id");
		var giftCardValue = contact.find('.occasion_gift_card_sku');
		//debugger;
		if(giftCard != "") {
			$("<i class='fa fa-spinner fa-2 fa-spin gift-card-loading-icon' aria-hidden='true'></i>").insertAfter($(this));
		}
		
		var remove = contact.find('.remove-from-schedule');
		if(remove.length > 0) {
			remove.replaceWith("<div class='add-to-schedule'>Update Order</div>");
		}
		
		if(giftCard != "") {
			$.ajax({

					url: '/dashboards/get_gift_card_values',
					type: "POST",
					data: {
							gift_card: giftCard,
							//contact_id: contactId,
					},
					dataType: "json",
					success: function (data) {
							activeOccasion.find('.gift-card-loading-icon').remove();
							var options = data.options.data;
							giftCardValue.html(options);
							var $select = giftCardValue;
							$select.append($('<option value="">Choose Gift Card Value</option>'));
							$.each(options, function(i, val){
									$select.append($('<option />', { value: val.id, text: "$" + val.attributes["value"] }));
							});
							giftCardValue.addClass('show').focus();
					}
			});		
		}
		else {
			giftCardValue.val("");
			giftCardValue.removeClass('show').removeClass('error');
		}
    
		
		//var giftCardProvider = $(this).val();
    /*var remove = contact.find('.remove-from-schedule');
		if(remove.length > 0) {
			remove.replaceWith("<div class='add-to-schedule'>Update Order</div>");
		}*/
		/*if(giftCardProvider != "Add Gift Card") {
			giftCard.css('display', 'inline-block').focus();
		}
		else {
			giftCard.css('display', 'none');
		}*/
  });
	
	// when the gift card amount changes change the button to read "Update Order"
	$('#contact-view').on('change', '.occasion_gift_card_sku', function(event) {
		$(this).removeClass('error');
		//debugger;
    var contact = $(event.target).closest('.contact');
		
    var remove = contact.find('.remove-from-schedule');
		if(remove.length > 0) {
			remove.replaceWith("<div class='add-to-schedule'>Update Order</div>");
		}
  });
	
	// when the date changes change the button to read "Update Order"
	$('#contact-view').on('change', '.date', function(event) {
		//debugger;
    var contact = $(event.target).closest('.contact');
    var remove = contact.find('.remove-from-schedule');
		if(remove.length > 0) {
			remove.replaceWith("<div class='add-to-schedule'>Update Order</div>");
		}
  });
	
	$('body').on('click', '#contact-view .card-interior', function(event) {
		
		var tab = $(event.currentTarget).parents('.tab');
		var cards = $(event.currentTarget).parents('.cards');
		var activeCard = cards.find('.active-card');
		var cardOptions = tab.find('.card-options').addClass('options-active');
		
		tab.find('.card-id').val("");
			cardOptions.removeClass('options-active');
			removeCards(cards, activeCard, false);
			activeCard.removeClass('active-card');	

			var removeButton = cardOptions.find('.remove-from-schedule');
			if(removeButton.length > 0) {
				removeButton.replaceWith("<div class='add-to-schedule'>Update Order</div>");
			}

			var index = activeCard.data('slick-index') || activeCard.data('index') - 1;

			cards.slick('slickSetOption', 'swipe', true);

			cardOptions.hide();

			var scrollControls = tab.find('.slick-arrow');
			scrollControls.show();
	});
							 
	$('body').on('click', '#contact-view .card-exterior, .click-to-open', function(event) {
  //$('#contact-view').on('click', '.card-exterior', function(event) {
    var tab = $(event.currentTarget).parents('.tab');
		//var card = $(event.currentTarget).parents('.card');
		var cards = $(event.currentTarget).parents('.cards');
		//debugger;
		var card = cards.find('.slick-current');
    var cardControls = tab.find('.card-controls');
		var activeCard = $(event.currentTarget).parents('.active-card');
		var cardOptions = tab.find('.card-options').addClass('options-active');//.detach();
		var optionsMenu = tab.find('.options-menu');
		var openCard = card.find('.open-card');
		var selectCard = tab.find('.select-card');
		var cardId = card.data('card-id');
		
		if(activeCard.length > 0) {
			tab.find('.card-id').val("");
			cardOptions.removeClass('options-active');
			removeCards(cards, card, false);
			card.removeClass('active-card');
			cards.removeClass('selected-card');
			//$(selectCard).append(cardOptions);
			//cards.on('beforeChange', function(event, slick, currentSlide, nextSlide){
				
				//cards.slick('setPosition');
				//cards.unbind('beforeChange');
			//});
			var removeButton = cardOptions.find('.remove-from-schedule');
			if(removeButton.length > 0) {
				removeButton.replaceWith("<div class='add-to-schedule'>Update Order</div>");
			}

			
			//cards.slick('slickUnfilter');
			
			var index = activeCard.data('slick-index') || activeCard.data('index') - 1;
			
			//cards.slick('unslick');
			// must set slidesToScroll to 1 so chosen card is first card of 3 shown when card is unchosen
			//cards.slick('slickSetOption', 'slidesToScroll', 1);
			//cards.slick('slickSetOption', 'slidesToShow', 1);
			//cards.slick('slickSetOption', 'responsive', [{breakpoint: 480, settings: {slidesToShow: 1}}]);
			//cards.slick('slickGoTo', index + 1);
			
			
			//cards.slick('slickSetOption', 'slidesToScroll', 3);
			/*cards.slick({
				initialSlide: index,
				infinite: false,
				slidesToShow: 3,
				slidesToScroll: 3,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: true,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]}, true);*/
			//console.log("Index: " + index, "Current Slide: " + cards.slick('slickCurrentSlide'));
			cards.slick('slickSetOption', 'swipe', true);
			
			//card.addClass('slick-current');
			//cards.slick('setPosition');
			cardOptions.hide();
			//cardOptions.removeClass('options-active');
			//optionsMenu.hide();
			var scrollControls = tab.find('.slick-arrow');
			scrollControls.show();
			
    }
		else {
			tab.find('.card-id').val(cardId);	
			//debugger;
			card.addClass('active-card');
			/*cards.on('afterChange', function(event, slick, currentSlide, nextSlide){
			var left = card.offset().left - card.width();
			debugger;
			card.find('.card-interior').css({ 'position':'fixed', 'left': left });
			});*/
			//debugger;
				addCards(cards, card, false);
			cards.addClass('selected-card');
			var scrollControls = tab.find('.slick-arrow');
				scrollControls.hide();
				
				//cards.find('.active-card').show();
				cardOptions.show();
			cards.slick('slickSetOption', 'swipe', false);
			//cards.slick('slickSetOption', 'focusOnSelect', false);
			/*cards.on('afterChange', function(event, slick, currentSlide, nextSlide){
				card.addClass('active-card');
			});*/
			/*cards.on('afterChange', function(event, slick, currentSlide, nextSlide){
				//debugger;
				for(i=0; i<2; i++) {
					var newCard = card.clone();
					//newCard.find('.card-exterior').remove();
					//newCard.find('.card-interior').addClass('card-exterior').removeClass('card-interior');
					newCard.removeClass('active-card').removeClass('slick-current').removeClass('slick-active');
					

					var cardIndex = card.data('slick-index');
					
					cards.slick('slickAdd', newCard, cardIndex);
					
				}
				cards.slick('slickGoTo', cardIndex, true);
				//card.next('.card').append(newCard);
				//cards.slick('slickFilter', '.active-card');
				cards.slick('slickSetOption', 'swipe', false);
				
				cards.on('setPosition', function(event) {
					//card.width(card.width()*3);
					cards.unbind('setPosition');
				});
				
				
				
				//card.append(cardOptions);
				//cardOptions.show();
				//optionsMenu.show();
				cards.unbind('afterChange');
			});*/
			
		}
  });

  /*$('#contact-view').on('click', '.card-interior', function(event) {
    var tab = $(event.currentTarget).parents('.tab');
    var cardControls = tab.find('.card-controls');
    
		var card = $(this).parents('.card');
    
		card.removeClass('active-card');
    $(event.currentTarget).hide();
    $(event.currentTarget).prev('.card-exterior').show();
		card.find('.close-card').replaceWith("<div class='open-card'>Open Card</div>");
    //cardControls.show();
    
  });*/
	
	$('body').on('click', '#contact-view .left-side', function(event) {
		//debugger;
		
		if(!$(this).hasClass('active')) {
			var card = $(this).parents('.card');
			var closeCard = card.find('.close-card');
			var cards = card.parents('.cards');
			var cardIndex = card.data('slick-index') - 1;
			var tab = $(event.currentTarget).parents('.tab');
			
			var rightInterior = tab.find('.card-interior.right');
			var leftInterior = tab.find('.card-interior.left');
			
			rightInterior.css('margin-left', '-96px'); //
			leftInterior.css('margin-left', '5px');

			//$(this).removeClass('active');
			//$('.cards').eq(1).slick('slickGoTo', 1, true);
			//cards.slick('slickGoTo', cardIndex, true);
			
			cards.slick('unslick');
			cards.slick({
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: false,
				draggable: false,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]
			});
			cards.slick('slickGoTo', cardIndex, true);
			var scrollControls = cards.find('.slick-arrow');
			scrollControls.hide();
			//.slick('slick')
			//cards.slick('slickPrev');
			/*setTimeout(function() {
				cards.slick('slickGoTo', cardIndex, true);
			}, 600);*/
		}
	});
	
	$('body').on('click', '#contact-view .right-side', function(event) {
	//$('#contact-view').on('click', '.right-side', function(event) {
		//debugger;
		
		if(!$(this).hasClass('active')) {
			var card = $(this).parents('.card');
			var closeCard = card.find('.close-card');
			var cards = card.parents('.cards');
			var cardIndex = card.data('slick-index') + 1;
			var tab = $(event.currentTarget).parents('.tab');
			
			var rightInterior = tab.find('.card-interior.right');
			var leftInterior = tab.find('.card-interior.left');
			
			rightInterior.css({'margin': '0 auto','margin-right': '0'});
			
			var marginLeftRightInterior = Math.round(parseInt(cards.find('.card-interior.right').css('margin-left'))) + 1;
			var cardImageWidth = Math.round(cards.find('.card-interior.right').width());
			var cardsWidth = Math.round(cards.width());
			var marginLeftLeftInterior = cardsWidth - cardImageWidth + marginLeftRightInterior;
			
			leftInterior.css('margin-left', marginLeftLeftInterior); // 222px;

			//$(this).removeClass('active');
			//$('.cards').eq(1).slick('slickGoTo', 2, true);
			//cards.slick('slickGoTo', cardIndex, true);
			cards.slick('unslick');
			cards.slick({
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				focusOnSelect: true,
				touchThreshold: 10,
				respondTo: 'window',
				swipe: false,
				draggable: false,
				prevArrow: "<i class='material-icons scroll-left slick-left'>keyboard_arrow_left</i>",
				nextArrow: "<i class='material-icons scroll-right slick-right'>keyboard_arrow_right</i>",
				responsive: [
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
				]
			});
			cards.slick('slickGoTo', cardIndex, true);
			var scrollControls = cards.find('.slick-arrow');
			scrollControls.hide();
			/*setTimeout(function() {
				cards.slick('slickGoTo', cardIndex, true);
			}, 600);*/
		}
	});
	
	$('body').on('click', '#contact-view .open-card', function(event) {
	//$('#contact-view').on('click', '.open-card', function(event) {
		var card = $(this).parents('.card');
		var cardInterior = card.find('.card-interior');
		var cardExterior = card.find('.card-exterior');
		var closeCard = card.find('.close-card');
		var cards = card.parents('.cards');
		var cardIndex = card.data('slick-index') + 2;
		var tab = $(event.currentTarget).parents('.tab');
		//console.log(tab);
		cards.slick('slickSetOption', 'swipe', false);

		var open = true;
		addCards(cards, card, open);
		
		//card.addClass('active-card');
		//cardExterior.hide();
		//cardInterior.show();
		//$(this).replaceWith("<div class='close-card'>Close Card</div>");
		//closeCard.show();
		//$(event.currentTarget).next('.card-interior').show();
	});
	
	$('body').on('click', '#contact-view .close-card', function(event) {
	//$('#contact-view').on('click', '.close-card', function(event) {
		var card = $(this).parents('.card');
		var cards = card.parents('.cards');
		var cardInterior = card.find('.card-interior');
		var cardExterior = card.find('.card-exterior');
		
		var tab = $(event.currentTarget).parents('.tab');
		//card.addClass('active-card');
		//cardExterior.show();
		//cardInterior.hide();
		removeCards(cards, card, true);
		
		var scrollControls = tab.find('.slick-arrow');
		scrollControls.show();
		cards.slick('slickSetOption', 'swipe', true);
		//$(this).replaceWith("<div class='open-card'>Open Card</div>");
		//openCard.show();
		//$(event.currentTarget).next('.card-interior').show();
	});
  
  // change the card index to reflect the current card index
  $('.active-card').each(function(event) {
    var startingIndex = $(this).data('index');
    $(this).parents('.tab').eq(0).find('.current-index').text(startingIndex);                    
  });
	
	$('body').on('click', '.add-card', function(event) {
		var contact = $(event.currentTarget).closest('.contact');
		contact.find('.tab-list').show();
	});
  
  // when the user clicks the edit button show the option to delete contact and allow contact name to be edited
  $('body').on('click', '.edit-contact', function(event) {
    
    var contact = $(event.target).closest('.contact');
    
    $(this).toggleClass('active');
    
    if(!contact.hasClass('active-edit')) {
      contact.addClass('active-edit');   
      contact.find('.enter-name').show(); //.focus(); 
      contact.find('.name').hide();
      //contact.find('.edit-contact').hide();
      contact.find('.delete-contact').show();
    }
    else {
      contact.removeClass('active-edit');
      contact.find('.enter-name').hide().blur();
      contact.find('.name').show();
      //contact.find('.edit-contact').hide();
      contact.find('.delete-contact').hide();
    }
    
  });
	
	// change the contact name when user presses enter or clicks outside enter-name field
	$('.enter-name').on('focusout', function(event) {
		
			var contact = $(event.currentTarget).closest('.contact'); 
      var name = $(this).val();
			var existingName = $.trim(contact.find('.name').text());
		
			if(name != existingName) {
				if(name === '') {
					contact.remove();
				}
				else {
					//contact.find('.name').text(name).prepend('<i class="material-icons arrow">arrow_drop_down</i>').show();
					//contact.find('.details-row').show();
					//$('.contact').removeClass('active-contact');

					$(this).hide();
					//var contact = $(this).closest('.contact');

					var newName = /*"<i class='material-icons arrow'>arrow_drop_down</i>" + */$(this).val();
					$(this).siblings('.name').html(newName);
					contact.find('.name').show();
					contact.find('.edit-contact').show();


					var contactId = contact.find('.contact-id').val();

					$.ajax({

							url: '/dashboards/edit_contact',
							type: "POST",
							data: {
									contact_id: contactId,
									name: name
							},
							dataType: "json",
							success: function () {
									contact.find('.delete-contact').hide();
									contact.removeClass('active-edit');
								contact.find('.edit-contact').removeClass('active');
							}
					});
					//contact.find('.contact').addClass('active-contact');

					//scrollToContact(contact.find('.contact')); //.closest('.contact')
				}
			}
			
    });
    
  $('.enter-name').on('keydown', function(event) {
    // if user presses enter button on keyboard
    if(event.keyCode === 13) {
      // remove focus from enter-name input
      $(event.target).blur();
    }
    else {
      return;
    }
  });
	
	
	
	$('body').on('click', ".close-contact", function(event) {
		closeContact();
	});
	
  // confirm user wants to delete contact
  $(".delete-contact").on('click', function(event) {
    var contact = $(event.target).closest('.contact');
    if (confirm('Delete contact?')) {
			var contactId = contact.find('.contact-id').val();
			
			// if an ajax request is underway prevent user from creating another
			if(!$(event.currentTarget).hasClass('submitting')) {
				// set flag that ajax request is underway
				$(event.currentTarget).addClass('submitting');

					$.ajax({

							url: '/dashboards/delete_contact',
							type: "POST",
							data: {
									contact_id: contactId,
							},
							dataType: "json",
							success: function () {
								// remove flag that ajax request is underway
								$(event.currentTarget).removeClass('submitting');
								
								contact.remove();
								$('.contact').show();
							}
					});
			}
    } else {
        $(this).val(false);
    }
    //$('form').submit();
    //$(contact).hide();
  });
  
  // change icon from circle with plus to circle with check mark to reflect that user has selected contact to import
  $('#imported-contacts .imported-contact').on("click", function(event) {
    
    var icon = $(event.currentTarget).find('.add-contact');
    
      if($(icon).hasClass('add-circle')) {
        $(icon).removeClass('add-circle').addClass('check-circle').text('check_circle');
      }
      else {
        $(icon).removeClass('check-circle').addClass('add-circle').text('add_circle');
      }
     
  });
	
	$('.process-order').on("click", function(event) {
		
		var orderId = parseInt($(this).parent().siblings('.order-id').text());
		
		$.ajax({

						url: '/dashboards/process_order',
						type: "POST",
						data: {
							order_id: orderId
						},
						dataType: "json",
						success: function () {
							
						}
				});
	});
  
  // get the contacts the user has selected to import, add contacts as new form fields, and save form
  $('#add-imported-contacts').on("click", function(event) {
		
		//$('#add-imported-contacts').remove();
		
		/*$('#imported-contacts > .imported-contact').each(function() {
			var noImport = $(this).find('.add-circle');
			if(noImport.length > 0) {
				$(this).remove();
			}
			else {
				$(this).hide();
			}
		});*/
		//$('.check-circle').parents('.imported-contact').unwrap();
		//$('#add-imported-contacts').hide();
		
		/*$('.add-circle').each(function(event) {   
			$(this).remove();
		});*/
		var total = $('.check-circle').length;												
    $('.check-circle').each(function(index, event) {   
      
      //$(this).next('.add_nested_fields').click();  
      var contact = $(document).find('.imported-contact').eq(0);
      
      var importedContact = $(this).closest('.imported-contact');
      //debugger;
			var name = importedContact.find('.imported-name').val();
      var birthday = importedContact.find('.imported-birthday').text();
      contact.find('.contact-birthday').val(birthday);
      
      var street1 = importedContact.find('.street-1').text();
      
      if(street1 !== "") {
        
        //var addAddress = contact.find('.add_nested_fields').eq(0);
        //addAddress.click();
     
        var street2 = importedContact.find('.address-2').text();
        var city = importedContact.find('.city').text();
        var state = importedContact.find('.state').text();
        var zipCode = importedContact.find('.zip-code').text();

        /*contact.find('.street-1').val(street1);
        contact.find('.street-2').val(street2);
        contact.find('.city').val(city);
        contact.find('.state').val(state);
        contact.find('.zip-code').val(zipCode);*/
      }

			$.ajax({

						url: '/dashboards/add_contact',
						type: "POST",
						data: {
							name: name,
							birthday: birthday,
							street_1: street1,
							street_2: street2,
							city: city,
							state: state,
							zip_code: zipCode
						},
						dataType: "script",
						success: function () {
							//debugger;
							$('#imported-contacts').removeClass('active-occasion');
							$('#contact-view').removeClass('fixed');
							importedContact.remove();
							/*if (index === total - 1) {
									importedContact.unwrap();
							}*/
								//$('.enter-new-contact').remove();
						}
				});
			
			});
  });
  
  // show import contact options gmail, yahoo, hotmail, and outlook
  $('#import-contacts').on("click", function(event) {
		$('#contact-view').addClass('fixed');
		$('#contact-view').find('.active-occasion').removeClass('active-occasion');
    $('#imported-contacts').addClass('active-occasion');
  });

  // show or hide side menu when user clicks on hamburger menu
  $('.hamburger-icon').on( "click", function (e) {
      
			if($('#myTopnav').hasClass('responsive')) {
				$('#myTopnav').removeClass('responsive');
			}
			else {
				$('#myTopnav').addClass('responsive');
			}
		    
	});
  

});