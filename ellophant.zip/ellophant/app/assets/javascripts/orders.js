$(document).on("ready", function(event) {
  $('#excel').on('click', function(event) {
  $.ajax({
      url: '/orders/generate_excel_file',
      type: "POST",
      dataType: "script",
      success: function () {
          alert('success');
      }
    });
  });
  
  $("#delete-orders").on("click", function(event) {
      $.ajax({

          url: '/orders/delete_orders',
          type: "POST",
          dataType: "script",
          /*success: function () {
            tab.closest('.occasion').find('.occasion-id').val("");
            $("<div class='add-to-schedule'>Add to Schedule</div>").insertBefore($(event.target));
            $(event.target).remove();
          }*/
      });
    });
});