class GiftCardsController < ApplicationController
  def index
    if user_signed_in? && current_user.admin?
      @gift_cards = GiftCard.all
    else
      redirect_to "/"
    end
    
  end

  def new
  end

  def edit
  end

  def create
  end

  def delete
  end
  
  def import
     GiftCard.import(gift_card_import_params)
     redirect_to "/gift_cards", notice: "Gift cards imported."
  end  
  
  private

    def gift_card_import_params
      params.require(:file)#.permit(:file)
    end
end
