class DashboardsController < ApplicationController
  require 'google/apis/people_v1'
  require 'json'
  require 'stripe'
  
  Stripe.api_key # = Rails.application.secrets.secret_key
  
  before_action :authenticate_user!

  def index

    #people = Google::Apis::PeopleV1::PeopleService.new
    #people.authorization = authorization
    #puts people.inspect
    #people.authorization = authorization

    @user = current_user
    @contacts = Contact.where( user_id: current_user.id ).where.not( deleted: true )
    @occasions = Occasion.all

    customer =  Customer.find_by_user_id( current_user.id )
    
    @orders = Order.where( user_id: current_user.id ).order(:date)
    
=begin
    if Rails.env.production?
      @gift_cards = Stripe::Product.retrieve("prod_A73JUt4Rcm0dk0")["skus"]
    else
      @gift_cards = Stripe::Product.retrieve("prod_9zDwgmMQXWF8gK")["skus"]
    end
=end
    
    @customer = Customer.find_by_user_id( current_user.id )
    
    if @customer && @customer.address != nil
      @return_address = Address.find( @customer.address )
    else
      @return_address = nil
    end

    #Occasion.where( :user_id => current_user.id )
    
    if @customer
      @last4 = @customer.last4

      if @last4
        @submit = "Update Payment Info"
      else
        @submit = "Add Payment Info"
      end
    else
      @last4 = nil
      @submit = "Add Payment Info"
    end
    
    #contact = @user.contacts
    #contacts = @user.contacts.build
    
    #@contacts.each do |contact|
    #  contact.occasions.each do |occasion|
    #    occasion.name = 'Hanukkah'
    #  end
    #end
    #@user.occasions.build
    #contact = @user.contacts.build
    #@user.contact.address = Address.new 

    @imported_contacts = request.env['omnicontacts.contacts']
    #@user = request.env['omnicontacts.user']
    #@omni_contacts = request.env['omnicontacts']
    current_year = Date.today.year
    from = Date.civil(current_year,1,1)
    to = Date.civil(current_year,12,31)

    @holidays = Holidays.between(from, to, :us).delete_if{
      |obj|
      obj[:name]=='Martin Luther King, Jr. Day' ||
      obj[:name]=='Presidents\' Day' ||
      obj[:name]=='Memorial Day' ||
      obj[:name]=='Independence Day' ||
      obj[:name]=='Labor Day' ||
      obj[:name]=='Columbus Day' ||
      obj[:name]=='Veterans Day'
    }
    
    @holidays.each do |holiday|
      case holiday[:name]
        when 'Thanksgiving'
          @thanksgiving_date = holiday[:date]
        when 'Christmas Day'
          @christmas_date = holiday[:date]
        when 'New Year\'s Day'
          @newyears_date = holiday[:date]
      end
    end
    
    case Date.today.year.to_s
      when '2016'
        @hanukkah_date = '2016-12-24'
      when '2017'
        @hanukkah_date = '2017-12-12'
      when '2018'
        @hanukkah_date = '2018-12-02'
      when '2019'
        @hanukkah_date = '2019-12-22'
      when '2020'
        @hanukkah_date = '2020-12-10'
      when '2021'
        @hanukkah_date = '2021-11-28'
      when '2022'
        @hanukkah_date = '2022-12-18'
      when '2023'
        @hanukkah_date = '2023-12-07'
      when '2024'
        @hanukkah_date = '2024-12-25'
      when '2025'
        @hanukkah_date = '2025-12-14'
    end
    
    #Holidays.load_custom('/home/user/holiday_definitions/hanukkah.yaml')
    
    @birthday_cards = Card.where(occasion: 'birthday')
    @christmas_cards = Card.where(occasion: 'christmas')
    @hanukkah_cards = Card.where(occasion: 'hanukkah')
    @thanksgiving_cards = Card.where(occasion: 'thanksgiving')
    @weddinganniversary_cards = Card.where(occasion: 'wedding-anniversary')
    @workanniversary_cards = Card.where(occasion: 'work-anniversary')
    @newyears_card = Card.where(occasion: 'new-year')
    
    #@occasions = Occasion.where(name: 'christmas')
    
    if params[:occasion_name]
      @occasion_name = params[:occasion_name]
      @cards = Card.where('occasion = ?', @occasion_name)
    end
    
    respond_to do |format|
      format.html
      format.js
    end
   
  end
  
  def delete_contact
    contact_id = params[:contact_id]
    contact = Contact.find( contact_id )
    
    if current_user.id == contact.user_id
      
      occasions = Occasion.where( contact_id: contact.id )
      
      occasions.each do |occasion|
        if occasion.date.future?

          order = Order.find( occasion.order_id )
          
          occasions_in_order = Occasion.where( order_id: order.id ).count
          
          if occasions_in_order == 1
            Delayed::Job.find( order.job_id ).destroy
            order.destroy
          end
          
          occasion.destroy
        end
      end
      
      remaining_occasions = Occasion.where( contact_id: contact.id ).count

      if remaining_occasions == 0
        contact.destroy
      else
        contact.update( deleted: true )
      end

      render json: {
        status: 200,
        #message: "Successfully created todo list.",
        #todo_list: list
      }.to_json
    end
  end
  
  def edit_contact
    contact_id = params[:contact_id]
    @contact = Contact.find( contact_id )
    
    if current_user.id == @contact.user_id
    
      if @contact
        @contact.update( name: params[:name] )
        render json: {
          status: 200,
          #message: "Successfully created todo list.",
          #todo_list: list
        }.to_json
      else
        render json: {
          status: 500,
          #message: "Successfully created todo list.",
          #todo_list: list
        }.to_json
      end
      
    end
    
  end
  
  def add_contact
    contact_name = params[:name]
    
    @contact = Contact.create!( name: contact_name, user_id: current_user.id, birthday: params[:birthday] )
    
    if @contact && params[:street_1] != "" && params[:street_1] != nil
      @address = Address.create( user_id: current_user.id, contact_id: @contact.id, street_1: params[:street_1], street_2: params[:street_2], city: params[:city], state: params[:state], zip_code: params[:zip_code] )
    end
    
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def add_address
    if params[:address_id] == nil
      #contact_id = params[:contact_id].to_i
      @contact = Contact.find( params[:contact_id] )
      
      if current_user.id == @contact.user_id
        @address = Address.create( user_id: current_user.id, contact_id: params[:contact_id], street_1: params[:street_1], street_2: params[:street_2], city: params[:city], state: params[:state], zip_code: params[:zip_code] )
      end
    else
      #contact_id = params[:contact_id].to_i
      @contact = Contact.find( params[:contact_id] )
      
      if current_user.id == @contact.user_id
        @address = Address.find( params[:address_id] )
        @address.update( user_id: current_user.id, contact_id: params[:contact_id], street_1: params[:street_1], street_2: params[:street_2], city: params[:city], state: params[:state], zip_code: params[:zip_code] )
      end
    end
    
    respond_to do |format|
      format.html
      format.js
    end
  end
  
  def add_return_address
    
    if params[:address_id] == ""
      #contact_id = params[:contact_id].to_i
      @customer = Customer.find_by_user_id( current_user.id )
      
      if current_user.id == @customer.user_id
        @return_address = Address.create!( user_id: current_user.id, street_1: params[:street_1], street_2: params[:street_2], city: params[:city], state: params[:state], zip_code: params[:zip_code] )
        @customer.update( address: @return_address.id )
      end
    else
      @customer = Customer.find_by_user_id( current_user.id )
      
      if current_user.id == @customer.user_id
        @return_address = Address.find( params[:address_id] )
        @return_address.update( street_1: params[:street_1], street_2: params[:street_2], city: params[:city], state: params[:state], zip_code: params[:zip_code] )
      end
    end
    
    render json: {
      status: 200
    }.to_json
    
  end
  
  def process_order
    
    order_id = params[:order_id]
    
    order = Order.find( order_id )
    job_id = order.job_id
    Delayed::Job.find( job_id ).invoke_job
    
    render json: {
      status: 200
    }.to_json
  end
  
  def add_occasion
    
    @contact_id = params[:contact_id]
    @occasion_name = params[:occasion_name]
    @cards = Card.where('occasion = ?', @occasion_name)
    if Rails.env.production?
      @gift_cards = Stripe::Product.retrieve("prod_A73JUt4Rcm0dk0")["skus"]
    else
      @gift_cards = Stripe::Product.retrieve("prod_9zDwgmMQXWF8gK")["skus"]
    end
    
    respond_to do |format|
      format.html
      format.js
    end
    
  end
  
  def remove_from_order

    @occasion = Occasion.find( params[:occasion_id] )

    #@order = Order.find( params[:order_id] )
    
    #@occasion = Occasion.find( occasion_params[:id] )
    occasions = Occasion.where( order_id: @occasion.order_id )
    
    @contact = Contact.find( @occasion.contact_id )
    
    if current_user.id == @contact.user_id
    
      @occasion_id = @occasion.id
      @contact_id = @contact.id

      @order = Order.find( @occasion.order_id )

      if occasions.count == 1
        @order_id = @order.id

        Delayed::Job.find( @order.job_id ).destroy
        @order.destroy
        @order_exists = false
      else
        @order_exists = true
      end

      @card = Card.find_by_card_id( @occasion.card_id )
      @scheduled_occasions = Occasion.where( order_id: @order.id ).order( :date, :name, :created_at )

      @occasion.destroy

      respond_to do |format|
        format.html
        format.js
      end
    end
  end
  
  def remove_from_schedule
    @occasion = Occasion.find( occasion_params[:id] )
    occasions = Occasion.where( order_id: @occasion.order_id )
    
    @contact = Contact.find( @occasion.contact_id )
    
    if current_user.id == @contact.user_id
    
      @occasion_id = @occasion.id
      @contact_id = @contact.id

      @order = Order.find( @occasion.order_id )

      if occasions.count == 1
        @order_id = @order.id

        Delayed::Job.find( @order.job_id ).destroy
        @order.destroy
        @order_exists = false
      else
        @order_exists = true
      end

      @card = Card.find_by_card_id( @occasion.card_id )
      @scheduled_occasions = Occasion.where( order_id: @order.id ).order( :date, :name, :created_at )

      @occasion.destroy

      respond_to do |format|
        format.html
        format.js
      end
    
=begin
      render json: {
        status: 200,
        #message: "Successfully created todo list.",
        #todo_list: list
      }.to_json
=end
    end
  end
  
  def update_order
    
  end
  
  def add_to_schedule

    if params[:date].to_date > 2.weeks.from_now.to_date
      
      if params[:date].to_date < 1.year.from_now.to_date

        if occasion_params[:id] != ""
          @occasion = Occasion.find(occasion_params[:id])
          @contact = Contact.find( @occasion.contact_id )

          if current_user.id == @contact.user_id
            @order = Order.find( @occasion.order_id )

            #date_to_charge = order.date.to_datetime - 2.week
            if occasion_params[:date].to_datetime == @occasion.date
              @occasion.update(occasion_params)
            else
              occasions = Occasion.where( order_id: @order.id )
              @occasion.update(occasion_params)

              if occasions.count == 1
                Delayed::Job.find( @order.job_id ).destroy
                date_to_charge = occasion_params[:date].to_datetime - 2.week
                delayed_job = @order.delay( run_at: date_to_charge ).create_stripe_order( current_user.id, @order.id )
                @order.update( job_id: delayed_job.id, date: date_to_charge )
              else

                if current_user.id == @contact.user_id
                  @order = create_order( @occasion )
                end

              end

            end

            respond_to do |format|
              format.js {
                render "update_order"
              }
            end

            #occasion.update( job_id: delayed_job.id )

          end
        else
          @occasion = Occasion.create!(occasion_params)
          @occasion.update( user_id: current_user.id )
          @contact = Contact.find( @occasion.contact_id )

          if current_user.id == @contact.user_id
            @order = create_order( @occasion )

            occasions_in_order = Occasion.where( order_id: @order.id ).count

            if occasions_in_order == 1

              respond_to do |format|
                format.js {
                  render "add_order"
                }
              end

            else

              respond_to do |format|
                format.js {
                  render "update_order"
                }
              end

            end

          end
        end

        @card = Card.find_by_card_id( @occasion.card_id )
        #@scheduled_occasions = Occasion.where( order_id: @order.id ).order( :date, :name, :created_at )
      else
      
        @contactId = params[:contact_id]
        @occasionName = params[:name]
        @error_message = "Cards cannot be scheduled more than a year in advance."

        respond_to do |format|
          format.js {
            render "date_error"
          }
        end
      
    end
      
    else
      
      @contactId = params[:contact_id]
      @occasionName = params[:name]
      @error_message = "Cards must be scheduled two weeks in advance."

      respond_to do |format|
        format.js {
          render "date_error"
        }
      end
      
    end
    
  end
  
  
  
  def create_card
    create_stripe_customer(cc_params[:name], cc_params[:token])  
  end
  
  def delete_card
    delete_stripe_card
  end

  def failure
    if params[:error_message]
      redirect_to '/dashboard', notice: "Error importing contacts. Try again."
    else 
      redirect_to '/dashboard'
    end
  end
  
  def get_gift_card_values
    
    gift_card = params[:gift_card]
        
    stripe_gift_card = Stripe::Product.retrieve(gift_card)
    gift_card_skus = stripe_gift_card["skus"]
    
    render json: {
      status: 200,
      options: gift_card_skus,
    }.to_json
    #respond_to do |format|
    #  format.js {
    #    render "gift_card_skus"
    #  }
    #end
  end
  
  private
  
    def cc_params
      params.permit(:utf8, :name, :token)
    end

    def occasion_params
      params.permit(:contact_id, :id, :date, :card_id, :name, :gift_card_provider, :gift_card_sku, :message)
    end

end
