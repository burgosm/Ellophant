class OrdersController < ApplicationController
  
  require 'axlsx'
  
  def index
    if user_signed_in? && current_user.admin?
      @all_pending_orders = Order.all.order(:date)
      @all_past_orders = Order.all.order(:date)
      @pending_occasions = Occasion.where( stripe_order_id: nil )
      @scheduled_occasions = Occasion.where.not( stripe_order_id: nil )
    else
      redirect_to "/dashboard"
    end
    
    
    
  end
  
  def generate_excel_file
    render xlsx: "index"
  end
  
  def delete_orders
    
    #orders = Order.all
    
    #orders.each do |order|
    #  occasion = Occasion.find_by_order_id( order.id )
    #  occasion.destroy if occasion != nil
      
    #  order.destroy
    #end
    Order.destroy_all
    Occasion.destroy_all
    Delayed::Job.destroy_all
    
    redirect_to '/orders'
    
  end
  
end
