class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  
  #before_filter :authenticate
=begin
  def authenticate
    authenticate_or_request_with_http_basic('Administration') do |username, password|
      username == 'admin' && password == 'Q7O$5vt9rc@N'
    end 
  end
=end
  
  def after_sign_in_path_for( resource ) 
    '/dashboard'
  end
  
    def create_stripe_customer(name, token)

        customer = Customer.find_by_user_id( current_user.id )

        if customer.nil?
            
            stripe_customer = Stripe::Customer.create(
                :card => token,
                :email => current_user.email
            )
      
            @last4 = stripe_customer.sources.data[0]['last4']
            
            customer = Customer.create!( :name => name, :user_id => current_user.id, :stripe_id => stripe_customer.id, :last4 => @last4 )

        else
          
            stripe_customer = Stripe::Customer.retrieve( customer.stripe_id )
            stripe_customer.source = token
            stripe_customer.save
      
            @last4 = stripe_customer.sources.data[0]['last4']
            
            customer.update!( :name => name, :user_id => current_user.id, :stripe_id => stripe_customer.id, :last4 => @last4 )
          
        end

        #create_stripe_card_for_customer(token, customer.customer_id)

        return customer

    end
  
    def create_order( occasion )
      date_to_charge = occasion[:date].to_datetime - 2.week
          
      order = Order.where( user_id: current_user.id, date: date_to_charge ).limit(1).first

      if order.nil?
        order = Order.create( user_id: current_user.id, date: date_to_charge )
        delayed_job = order.delay( run_at: date_to_charge ).create_stripe_order( current_user.id, order.id )
        order.update( job_id: delayed_job.id )
        occasion.update( order_id: order.id )
      else
        occasion.update_attributes( order_id: order.id )
      end
      
      return order

    end
    
    def delete_stripe_card
      customer = Customer.find_by_user_id( current_user.id )
      
      stripe_customer = Stripe::Customer.retrieve( customer.stripe_id )
      
      stripe_customer.sources.retrieve( stripe_customer.default_source ).delete()
      
      customer.update!( :last4 => nil )
      
      respond_to do |format|
        format.html
        format.js
      end
    
    end
      
end
