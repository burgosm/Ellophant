class LandingsController < ApplicationController
   
  def index
  end
  
end
