class CardsController < ApplicationController
  
  require "stripe"
  #Stripe.api_key = "sk_test_4M2pQqYmxZNaCWaPNB6EantG"
  
  #before_action :authenticate_user!
  
  def index
    if user_signed_in? && current_user.admin?
      @new_card = Card.new
      @cards = Card.all
    else
      redirect_to "/dashboard"
    end
    
  end
  
  def new
    @new_card = Card.new(card_params)

    occasion = card_params[:occasion]
    
    #card_exterior = card_params[:card_exterior].tempfile
    #card_interior = card_params[:card_interior].tempfile

    #exterior_filename = card_params[:card_exterior].original_filename
    #interior_filename = card_params[:card_interior].original_filename

    #card_exterior_path = File.join Rails.root, 'public', exterior_filename
    #card_interior_path = File.join Rails.root, 'public', interior_filename

    #File.open(card_exterior_path, 'wb') do |f| #unless File.exist?(path + 'assets/' + exterior_filename) 
    #  f.write(card_exterior.read)
    #end
    
    #File.open(card_interior_path, 'wb') do |f| #unless File.exist?(path + 'assets/' + exterior_filename) 
    #  f.write(card_interior.read)
    #end
    
    #exterior_image_location = root_url + exterior_filename
    #interior_image_location = root_url + interior_filename
    
    if @new_card.save
      
      exterior_front_image_location = @new_card.exterior_front.url
      
      if @new_card.interior_left.url == '/images/missing.jpg'
        interior_left_image_location = "https://www.ellophant.com/#{@new_card.interior_left.url}"
      else
        interior_left_image_location = @new_card.interior_left.url
      end
      
      if @new_card.interior_right.url == '/images/missing.jpg'
        interior_right_image_location = "https://www.ellophant.com/#{@new_card.interior_right.url}"
      else
        interior_right_image_location = @new_card.interior_right.url
      end
      
      

      stripe_product = Stripe::Product.create(
        :name => 'Card',
        :metadata => {
          'occasion' => @new_card.occasion
        },
        :images => [exterior_front_image_location, interior_left_image_location, interior_right_image_location],
        :shippable => false
      )

      stripe_sku = Stripe::SKU.create(
        :product => stripe_product.id,
        :price => 600,
        :currency => 'usd',
        :inventory => {
          'type' => 'infinite',
        }
      )
      
      @new_card.update!( card_id: stripe_sku.id )
      #card = Card.create!( card_id: stripe_sku.id, exterior: stripe_product.images[0], interior: stripe_product.images[1], occasion: stripe_product.metadata['occasion'] )

      redirect_to '/cards', notice: 'Card was successfully created.'
    else
       render action: 'new'
    end

  end
  
  private

    def card_params
      params.require(:card).permit(:exterior_front, :interior_left, :interior_right, :occasion)
    end
end
