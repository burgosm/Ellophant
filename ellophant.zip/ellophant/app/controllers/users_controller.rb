class UsersController < ApplicationController
  
  def create
    @user = User.new(:user)    
  end
  
  def update
    
    @user = User.find(params[:id])
    #@user.contact.address = Address.new 
    #contact = @user.contacts.build
    #address = contact.build_address

    saved = @user.update!(user_params)
    
    #job = Delayed::Job.find(params[:id])
    #job.destroy

    if saved
      create_orders
      #redirect_to '/dashboard'
      respond_to do |format|
        format.html
        format.js
      end
    else
      puts "NOT SAVED"
    end
    #else
      #puts "UNCHANGED"
    #end
    
  end
  
  private

    def user_params
      params.require(:user).permit(contacts_attributes: [:id, :name, :birthday, :_destroy, address_attributes: [:id, :street_1, :street_2, :city, :state, :zip_code, :country], occasions_attributes: [:id, :name, :date, :card_id, :message]])
    end
  
end
