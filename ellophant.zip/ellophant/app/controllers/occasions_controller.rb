class OccasionsController < ApplicationController
  def index
  end

  def new
  end

  def update
  end

  def delete
  end

  def create
  end
end
