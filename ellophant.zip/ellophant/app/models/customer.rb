# == Schema Information
#
# Table name: customers
#
#  id         :integer          not null, primary key
#  name       :string(255)
#  user_id    :integer
#  address    :integer
#  stripe_id  :string(255)
#  created_at :datetime
#  updated_at :datetime
#  last4      :string(255)
#

class Customer < ActiveRecord::Base
  belongs_to :user
end
