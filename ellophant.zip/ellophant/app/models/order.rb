# == Schema Information
#
# Table name: orders
#
#  id         :integer          not null, primary key
#  order_id   :string(255)
#  charge_id  :string(255)
#  date       :date
#  created_at :datetime
#  updated_at :datetime
#  user_id    :integer
#

require "stripe"

Stripe.api_key = Rails.application.secrets.secret_key

class Order < ActiveRecord::Base
  
   belongs_to :user
  
   scope :paid, -> { where('order_id != ? AND order_id != ?', "", "unprocessed") } #-> { where("order_id != ?", "") }
   scope :unpaid, -> { where(order_id: nil) }
  
  def get_next_years_date( occasion )
    
    next_year = Date.today.year + 1

    from = Date.civil(next_year,1,1)
    to = Date.civil(next_year,12,31)

    @holidays = Holidays.between(from, to, :us).delete_if{
      |obj|
      obj[:name]=='Martin Luther King, Jr. Day' ||
      obj[:name]=='Presidents\' Day' ||
      obj[:name]=='Memorial Day' ||
      obj[:name]=='Independence Day' ||
      obj[:name]=='Labor Day' ||
      obj[:name]=='Columbus Day' ||
      obj[:name]=='Veterans Day'
    }

    @holidays.each do |holiday|
      case holiday[:name]
        when 'Thanksgiving'
          @thanksgiving_date = holiday[:date]
        when 'Christmas Day'
          @christmas_date = holiday[:date]
        when 'New Year\'s Day'
          @newyears_date = holiday[:date]
      end
    end

    hanukkah_next_year = Date.today.year + 1

    case hanukkah_next_year.to_s
      when '2016'
        @hanukkah_date = '2016-12-24'
      when '2017'
        @hanukkah_date = '2017-12-12'
      when '2018'
        @hanukkah_date = '2018-12-02'
      when '2019'
        @hanukkah_date = '2019-12-22'
      when '2020'
        @hanukkah_date = '2020-12-10'
      when '2021'
        @hanukkah_date = '2021-11-28'
      when '2022'
        @hanukkah_date = '2022-12-18'
      when '2023'
        @hanukkah_date = '2023-12-07'
      when '2024'
        @hanukkah_date = '2024-12-25'
      when '2025'
        @hanukkah_date = '2025-12-14'
    end
    
    case occasion.name

    when 'birthday'
      next_year = occasion.date + 1.year
    when 'wedding-anniversary'
      next_year = occasion.date + 1.year
    when 'work-anniversary'
      next_year = occasion.date + 1.year
    when 'thanksgiving'
      next_year = @thanksgiving_date
    when 'hanukkah'
      next_year = @hanukkah_date
    when 'christmas'
      next_year = @christmas_date
    when 'new-year'
      next_year = @newyears_date
    end
    
    return next_year
    
  end
  
    def create_order( occasion )
      date_to_charge = occasion[:date].to_datetime - 2.week
          
      order = Order.where( user_id: occasion.user_id, date: date_to_charge ).limit(1).first

      if order.nil?
        order = Order.create( user_id: occasion.user_id, date: date_to_charge )
        delayed_job = order.delay( run_at: date_to_charge ).create_stripe_order( occasion.user_id, order.id )
        order.update( job_id: delayed_job.id )
        occasion.update( order_id: order.id )
      else
        occasion.update_attributes( order_id: order.id )
      end

    end

    def create_stripe_order( user_id, order_id )

      customer = Customer.find_by_user_id( user_id )
      
      stripe_id = customer.stripe_id if customer
              
      order = Order.find( order_id )
      
      occasions = Occasion.where( order_id: order.id )
      
      @items = []
      description = []
      same_gift_card = []
      same_card = []
      
      occasions.each do |occasion|
        
        if customer && customer.last4 != nil
        
          if occasion.card_id != nil

            if occasion.gift_card_sku != nil

              same_cards_count = Occasion.where( card_id: occasion.card_id, order_id: order.id ).count

              if !same_card.include? occasion.card_id
                @items << { :type => 'sku', :parent => occasion.card_id, :quantity => same_cards_count }
              end

              if same_cards_count > 1
                same_card << occasion.card_id
              end

              # Stripe: Cannot list the same SKU multiple times in order item list. Please use `quantity` to order more than one of a SKU.
              same_gift_cards_count = Occasion.where( gift_card_sku: occasion.gift_card_sku, order_id: order.id ).count

              # if we haven't already added this SKU to an item, add it to an item
              if !same_gift_card.include? occasion.gift_card_sku
                @items << { :type => 'sku', :parent => occasion.gift_card_sku, :quantity => same_gift_cards_count }
              end

              if same_gift_cards_count > 1
                same_gift_card << occasion.gift_card_sku
              end
              
              gift_card_price = Stripe::SKU.retrieve(occasion.gift_card_sku).price / 100
              contact_address = Contact.find( occasion.contact_id ).address
              contact_name = Contact.find( occasion.contact_id ).name
              @address = Address.find( contact_address )
              formatted_recipient_address = "#{contact_name}, #{@address.street_1} #{@address.street_2} #{@address.city}, #{@address.state} #{@address.zip_code}"
              occasion_details = "Occasion ID: #{occasion.id}\nArrival Date: #{occasion.date}\nGift Card: #{occasion.gift_card_provider}\nAmount: $#{gift_card_price}\nMessage: #{occasion.message}\nRecipient: #{formatted_recipient_address}\n"
              #@return_address = get_return_address occasion
              #formatted_return_address = "#{@return_address.street_1} #{@return_address.street_2} #{@return_address.city}, #{@return_address.state} #{@return_address.zip_code}"
              description << occasion_details

            else
              same_cards_count = Occasion.where( card_id: occasion.card_id, order_id: order.id ).count

              if !same_card.include? occasion.card_id
                @items << { :type => 'sku', :parent => occasion.card_id, :quantity => same_cards_count }
              end

              if same_cards_count > 1
                same_card << occasion.card_id
              end
              
              contact_address = Contact.find( occasion.contact_id ).address
              contact_name = Contact.find( occasion.contact_id ).name
              @address = Address.find( contact_address )
              formatted_recipient_address = "#{contact_name}, #{@address.street_1} #{@address.street_2} #{@address.city}, #{@address.state} #{@address.zip_code}"
              occasion_details = "Occasion ID: #{occasion.id}\nArrival Date: #{occasion.date}\nMessage: #{occasion.message}\nRecipient: #{formatted_recipient_address}\n"
              #@return_address = get_return_address occasion
              #formatted_return_address = "#{@return_address.street_1} #{@return_address.street_2} #{@return_address.city}, #{@return_address.state} #{@return_address.zip_code}"
               description << occasion_details

            end
                    
          else
            occasion.update( unprocessed: true, unprocessed_reason: "No greeting card" )
            
            #next_year = get_next_years_date occasion
            
            #next_years_occasion = Occasion.create!( name: occasion.name, date: next_year, contact_id: occasion.contact_id, user_id: occasion.user_id )
            #create_order( next_years_occasion )
          end
        
        else
          occasion.update( unprocessed: true, unprocessed_reason: "No credit card" )
          
          #next_year = get_next_years_date occasion
          
          #next_years_occasion = Occasion.create!( name: occasion.name, date: next_year, contact_id: occasion.contact_id, user_id: occasion.user_id )
          #create_order( next_years_occasion )
        end
        
      end
      
      if !@items.empty?
        begin
          

        stripe_order = Stripe::Order.create(
          #:amount   => amount,
          :currency => "usd",
          #:statement_descriptor => 'Ellophant.com',
          :customer => stripe_id,
          :items => @items
        )

        stripe_order.pay(
          :customer => stripe_id
        )

        if stripe_order.status == 'paid'
          
            stripe_charge = Stripe::Charge.retrieve(stripe_order.charge)
            stripe_charge.description = description.join("\n")
            stripe_charge.save

            order.update( order_id: stripe_order.id, charge_id: stripe_order.charge )

            occasions = Occasion.where( order_id: order.id )

            occasions.each do |occasion|

              if occasion.unprocessed != true
                occasion.update( stripe_order_id: stripe_order.id, charge_id: stripe_order.charge )
              end

              next_year = get_next_years_date occasion
              
              next_years_occasion = Occasion.create!( name: occasion.name, date: next_year, contact_id: occasion.contact_id, user_id: occasion.user_id )
              create_order( next_years_occasion )
            end

        else

        #    return false

        end

        rescue Stripe::CardError => e
            puts e.inspect
            body = e.json_body
            err  = body[:error]
            puts err.inspect  
            render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

            return false

        rescue Stripe::InvalidRequestError => e
          # Invalid parameters were supplied to Stripe's API
          puts e.inspect
          body = e.json_body
          err  = body[:error]
            puts err.inspect
          render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

          return false

        rescue Stripe::AuthenticationError => e
          # Authentication with Stripe's API failed (maybe you changed API keys recently)
          puts e.inspect
          body = e.json_body
          err  = body[:error]

          return render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

        rescue Stripe::APIConnectionError => e
          # Network communication with Stripe failed
          puts e.inspect
          body = e.json_body
          err  = body[:error]

          render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

          return false

        rescue Stripe::StripeError => e
          # Display a very generic error to the user, and maybe send yourself an email
          puts e.inspect
          body = e.json_body
          err  = body[:error]

          render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

          return false

        rescue => e

          # Something else happened, completely unrelated to Stripe
          puts e.inspect
          body = e.json_body
          err  = body[:error]

          render :json => { :status => e.http_status, :debit_failure_reason => body[:error][:message], :type => body[:error][:type], :code => body[:error][:code] }

          return false

        end
        
      end
      
      # if all occasions associated with an order went unprocessed, flag order as unprocessed so it doesn't show up in Orders List
      # prevents Order scope "unpaid" from including unprocessed orders which otherwise would have order_id == nil
      number_of_occasions_in_order = Occasion.where( order_id: order.id ).count
      number_of_occasions_in_order_unprocessed = Occasion.where( order_id: order.id, unprocessed: true ).count
      
      if number_of_occasions_in_order == number_of_occasions_in_order_unprocessed
        order.update( order_id: "unprocessed" )
      end

    end 
  
end
