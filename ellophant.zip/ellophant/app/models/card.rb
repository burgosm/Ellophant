# == Schema Information
#
# Table name: cards
#
#  id         :integer          not null, primary key
#  occasion   :string(255)
#  exterior   :string(255)
#  interior   :string(255)
#  created_at :datetime
#  updated_at :datetime
#  card_id    :string(255)
#

class Card < ActiveRecord::Base
  #belongs_to :occasion
  has_attached_file :exterior_front, :default_url => "/images/missing.jpg"
  has_attached_file :interior_left, :default_url => "/images/missing.jpg"
  has_attached_file :interior_right, :default_url => "/images/missing.jpg"
  
  validates_attachment_content_type :exterior_front, :content_type => /\Aimage\/.*\Z/
  validates_attachment_content_type :interior_left, :content_type => /\Aimage\/.*\Z/
  validates_attachment_content_type :interior_right, :content_type => /\Aimage\/.*\Z/
end
