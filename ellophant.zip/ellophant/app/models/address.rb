# == Schema Information
#
# Table name: addresses
#
#  id         :integer          not null, primary key
#  user_id    :integer
#  street_1   :string(255)
#  street_2   :string(255)
#  city       :string(255)
#  state      :string(255)
#  zip_code   :integer
#  country    :string(255)
#  created_at :datetime
#  updated_at :datetime
#  contact_id :integer
#

class Address < ActiveRecord::Base
  belongs_to :contact
end
