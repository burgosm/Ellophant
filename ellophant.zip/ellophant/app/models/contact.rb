# == Schema Information
#
# Table name: contacts
#
#  id         :integer          not null, primary key
#  created_at :datetime
#  updated_at :datetime
#  name       :string(255)
#  address    :integer
#  birthday   :date
#  user_id    :integer
#  address_id :integer
#

class Contact < ActiveRecord::Base
  validates :name, presence: true #:address,
  #has_many :occasions, :dependent => :destroy
  belongs_to :user
  has_one :address, :dependent => :destroy
  accepts_nested_attributes_for :address, allow_destroy: true
  has_many :occasions, :dependent => :destroy
  accepts_nested_attributes_for :occasions, allow_destroy:true
  default_scope { order('created_at DESC') } 
end
