# == Schema Information
#
# Table name: occasions
#
#  id                 :integer          not null, primary key
#  name               :string(255)
#  date               :date
#  message            :text
#  created_at         :datetime
#  updated_at         :datetime
#  contact_id         :integer
#  charge_id          :string(255)
#  job_id             :integer
#  stripe_order_id    :string(255)
#  order_id           :integer
#  gift_card_provider :string(255)
#  gift_card_amount   :integer
#  card_id            :string(255)
#

class Occasion < ActiveRecord::Base
  validates :name, :contact_id, presence: true #:date, :card_id
  
  belongs_to :contact
  
  #default_scope { where('occasions.date >= ?', Time.zone.now.to_date) }
  #scope :in_future, -> lambda { where('date >= ?', Time.zone.now.to_date) }
  #scope :in_future, where("date >= ?", Date.today)
  scope :in_future, -> { where("date >= ?", Date.today) }
  #has_many :cards
  NULL_ATTRS = %w( gift_card_provider gift_card_sku message )
  before_save :nil_if_blank

  protected

  def nil_if_blank
    NULL_ATTRS.each { |attr| self[attr] = nil if self[attr].blank? }
  end
end
