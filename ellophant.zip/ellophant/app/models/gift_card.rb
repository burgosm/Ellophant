class GiftCard < ActiveRecord::Base
  require 'roo'
  require "stripe"
  #Stripe.api_key = "sk_test_4M2pQqYmxZNaCWaPNB6EantG"
  
  def self.import(file)
=begin
    #gift_cards = GiftCard.all
    
    #gift_cards.each do |gift_card|   
      #gift_card.update!( stripe_id: gift_card.stripe_sku )
      products = Stripe::Product.list #.retrieve(gift_card.)  
      products.each do |product|
        #puts product.inspect
        skus = product["skus"]  
        
        skus.each do |sku|    
          puts sku.id
          Stripe::SKU.retrieve(sku.id).delete                                                                                           
        end   
      
        product.delete
      end
      #gift_card.destroy
    #end 
=end

	  spreadsheet = Roo::Spreadsheet.open(file.path, extension: :xlsx)
	  spreadsheet.default_sheet = "Import Gift Cards"
	  header = spreadsheet.row(1)

	  (2..spreadsheet.last_row).each do |i|
	    #row = Hash[[header, spreadsheet.row(i)].transpose]
      
      row = spreadsheet.row(i)
      
      row.each.with_index(1) do |cell, index|
          
        case index
          when 1   
            @retailer = cell
          
            @stripe_product = Stripe::Product.create(
              :name => cell,
              :shippable => false,
              :attributes => ["value"]
            )
                    
          when 2
            @min = cell
          when 3
            @max = cell
            puts @stripe_product.id
            GiftCard.create!( retailer: @retailer, stripe_id: @stripe_product.id, min: @min, max: @max )
          when 4..index
            if cell != nil
              stripe_sku = Stripe::SKU.create(
                :product => @stripe_product.id,
                :price => cell.floor*100,
                :currency => 'usd',
                :attributes => {
                  'value' => cell.floor.to_s,
                },
                :inventory => {
                  'type' => 'infinite',
                }
              )
           end

        #gift_card = new
	    
        #gift_card.attributes = row.to_hash.slice(*row.to_hash.keys)
        #gift_card.save!
          
        end
      end
	    
	  end

	end

	def self.open_spreadsheet(file)
	  case File.extname(file.original_filename)
	  when ".csv" then Roo::Csv.new(file.path, nil, :ignore)
	  when ".xls" then Roo::Excel.new(file.path, nil, :ignore)
	  when ".xlsx" then Roo::Excelx.new(file.path, nil, :ignore)
	  else raise "Unknown file type: #{file.original_filename}"
	  end
	end  	
      
  def accessible_attributes
   [:retailer, :min, :max]
  end
      
end
      
=begin
        stripe_product = Stripe::Product.create(
          :name => cell(index, i),
          :shippable => false
        )

        stripe_sku = Stripe::SKU.create(
          :product => stripe_product.id,
          :price => 600,
          :currency => 'usd',
          :inventory => {
            'type' => 'infinite',
          }
        )
=end