module DashboardsHelper
  def setup_address(contact)
    contact.address ||= Address.new
    contact
  end
  
  def get_stripe_order( occasion )
    stripe_order_id = Order.find( occasion.order_id ).order_id
  end
  
  def get_gift_card_price( occasion )
    if occasion.gift_card_sku != nil
      gift_card_sku = Stripe::SKU.retrieve(occasion.gift_card_sku).price / 100
    end
  end
  
  def get_gift_card_retailer( occasion )
    if occasion.gift_card_provider != nil
      retailer = GiftCard.find_by_stripe_id( occasion.gift_card_provider ).retailer
    end
  end
  
  def get_gift_card_skus( occasion )
    @gift_cards = Stripe::Product.retrieve( occasion.gift_card_provider )["skus"]
  end
  
  def my_titleize(str)
    str.gsub('-', ' ').titleize
  end
  
  def remove_dash(str)
    str.gsub('-', '')
  end
  
  def get_scheduled_occasions( order )
    @scheduled_occasions = Occasion.where( order_id: order.id ).where.not( unprocessed: true ).order( :date, :name, :created_at )
  end
  
  def get_contact_name( occasion )
    contact_name = Contact.find( occasion.contact_id ).name
  end
  
  def get_contact_address( occasion )
    contact_address = Contact.find( occasion.contact_id ).address
    @address = Address.find( contact_address.id ) if contact_address != nil
  end
  
  def get_return_address( occasion )
    @customer = Customer.find_by_user_id( occasion.user_id )
    if @customer && @customer.address
      @return_address = Address.find( @customer.address )
    else
      @return_address = nil
    end
  end
  
  def get_customer_name occasion
    @customer = Customer.find_by_user_id( occasion.user_id )
    if @customer
      return @customer.name
    end
  end
  
  def get_card( occasion )
      puts occasion.inspect
      card_exterior = Card.find_by_card_id( occasion.card_id ).exterior_front.url
  end
  
  def scheduled_occasion( contact, occasion_name )
    
    occasion = Occasion.where( user_id: current_user.id, contact_id: contact.id, name: occasion_name ).first
    
    if occasion
      content_tag(:div, class: 'tablink', :data => { :id => occasion_name, :title => my_titleize( occasion_name ) } ) do

        content_tag(:div, image_tag("#{remove_dash( occasion_name )}_icon.png") ) + 
        
        content_tag(:div, my_titleize( occasion_name ), class: 'occasion-name') + 
        
        content_tag(:div, class: "scheduled-for") do
          "Scheduled for: #{occasion.date.strftime("%-m/%-d/%Y")}"
        end
      end
    else
      content_tag(:div, class: 'tablink', :data => { :id => occasion_name, :title => my_titleize( occasion_name ) } ) do
        
        content_tag(:div, image_tag("#{remove_dash( occasion_name )}_icon.png") ) + 

        content_tag(:div, my_titleize( occasion_name ), class: 'occasion-name')
      end
    end
  end
  
  def scheduled_occasion_icons( contact, occasion_name )
    
    occasion = Occasion.where( user_id: current_user.id, contact_id: contact.id, name: occasion_name ).first
    
    if occasion
      content_tag( :div, class: 'iconlink', :data => { :id => occasion_name, :title => my_titleize( occasion_name ) } ) do
        image_tag "#{ remove_dash occasion_name }_icon.png", title: my_titleize( occasion_name )
      end
    else
      content_tag( :div, class: 'iconlink', :data => { :id => occasion_name, :title => my_titleize( occasion_name ) } ) do
        image_tag "#{ remove_dash occasion_name }_icon.png", title: my_titleize( occasion_name ), class: "grayscale"
      end
    end
  end
  
  def order_amount( order )
    occasions = Occasion.where( order_id: order.id ).where.not( unprocessed: true, card_id: nil )
    
    @order_amount = 0
    
    occasions.each do |occasion|
      if occasion.gift_card_sku != nil
        gift_card_sku = Stripe::SKU.retrieve(occasion.gift_card_sku).price
        @order_amount = @order_amount + ( gift_card_sku.to_i / 100 )
      end
    end
    
    cost_of_cards = occasions.count * 6
    
    @order_amount = @order_amount + cost_of_cards
  end
  
  def retrieve_cards(occasion_name)
    @cards = Card.where( occasion: occasion_name )
  end
  
  def set_date occasion_name, contact_id
    current_year = Date.today.year
    from = Date.civil(current_year,1,1)
    to = Date.civil(current_year,12,31)

    @holidays = Holidays.between(from, to, :us).delete_if{
      |obj|
      obj[:name]=='Martin Luther King, Jr. Day' ||
      obj[:name]=='Presidents\' Day' ||
      obj[:name]=='Memorial Day' ||
      obj[:name]=='Independence Day' ||
      obj[:name]=='Labor Day' ||
      obj[:name]=='Columbus Day' ||
      obj[:name]=='Veterans Day'
    }
    
    @holidays.each do |holiday|
      case holiday[:name]
        when 'Thanksgiving'
          @thanksgiving_date = holiday[:date]
        when 'Christmas Day'
          @christmas_date = holiday[:date]
        when 'New Year\'s Day'
          @newyears_date = holiday[:date]
      end
    end
    
    case Date.today.year.to_s
      when '2016'
        @hanukkah_date = '2016-12-24'
      when '2017'
        @hanukkah_date = '2017-12-12'
      when '2018'
        @hanukkah_date = '2018-12-02'
      when '2019'
        @hanukkah_date = '2019-12-22'
      when '2020'
        @hanukkah_date = '2020-12-10'
      when '2021'
        @hanukkah_date = '2021-11-28'
      when '2022'
        @hanukkah_date = '2022-12-18'
      when '2023'
        @hanukkah_date = '2023-12-07'
      when '2024'
        @hanukkah_date = '2024-12-25'
      when '2025'
        @hanukkah_date = '2025-12-14'
    end
    
    @contact = Contact.find( contact_id )
    
    case occasion_name
      when 'birthday'
        birthday = @contact.birthday
        if birthday.nil?
          @date = birthday
        else
          @date = birthday.change(:year => current_year)
        end
      when 'thanksgiving'
        @date = @thanksgiving_date
      when 'christmas'
        @date = @christmas_date
      when 'hanukkah'
        @date = @hanukkah_date.to_date
      when 'new-years'
        @date = @newyears_date
      when 'wedding-anniversary'
        @date = nil
      when 'work-anniversary'
        @date = nil
    end
  end
  
  def get_date(occasion_name, contact_id)
    
    set_date occasion_name, contact_id
    
    if !@date.nil? && !@date.future?

      current_year = Date.today.year + 1
      puts current_year
      from = Date.civil(current_year,1,1)
      to = Date.civil(current_year,12,31)

      @holidays = Holidays.between(from, to, :us).delete_if{
        |obj|
        obj[:name]=='Martin Luther King, Jr. Day' ||
        obj[:name]=='Presidents\' Day' ||
        obj[:name]=='Memorial Day' ||
        obj[:name]=='Independence Day' ||
        obj[:name]=='Labor Day' ||
        obj[:name]=='Columbus Day' ||
        obj[:name]=='Veterans Day'
      }

      @holidays.each do |holiday|
        case holiday[:name]
          when 'Thanksgiving'
            @thanksgiving_date = holiday[:date]
          when 'Christmas Day'
            @christmas_date = holiday[:date]
          when 'New Year\'s Day'
            @newyears_date = holiday[:date]
        end
      end
      case occasion_name
        when 'birthday'
          birthday = @contact.birthday
          if birthday.nil?
            @date = birthday
          else
            @date = birthday.change(:year => current_year)
          end
        when 'thanksgiving'
          @date = @thanksgiving_date
        when 'christmas'
          @date = @christmas_date
        when 'hanukkah'
          @date = @hanukkah_date.to_date
        when 'new-years'
          @date = @newyears_date
        when 'wedding-anniversary'
          @date = nil
        when 'work-anniversary'
          @date = nil
      end

    end

    return @date
  end
end
