class AddOrderIdToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :order_id, :integer
  end
end
