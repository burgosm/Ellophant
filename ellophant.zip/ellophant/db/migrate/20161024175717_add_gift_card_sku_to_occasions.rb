class AddGiftCardSkuToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :gift_card_sku, :string
  end
end
