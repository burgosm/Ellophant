class CreateCards < ActiveRecord::Migration
  def change
    create_table :cards do |t|
      t.integer :card_id
      t.string :occasion
      t.string :exterior
      t.string :interior

      t.timestamps
    end
  end
end
