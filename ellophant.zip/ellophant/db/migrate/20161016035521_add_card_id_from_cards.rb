class AddCardIdFromCards < ActiveRecord::Migration
  def change
    add_column :cards, :card_id, :string
  end
end
