class AddChargeIdToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :charge_id, :string
  end
end
