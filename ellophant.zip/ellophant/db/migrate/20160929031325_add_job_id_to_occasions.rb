class AddJobIdToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :job_id, :integer
  end
end
