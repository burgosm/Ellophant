class AddExteriorFrontToCards < ActiveRecord::Migration
  def self.up
    add_attachment :cards, :exterior_front
  end

  def self.down
    remove_attachment :cards, :exterior_front
  end
end
