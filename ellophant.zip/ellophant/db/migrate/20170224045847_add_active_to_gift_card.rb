class AddActiveToGiftCard < ActiveRecord::Migration
  def change
    add_column :gift_cards, :active, :binary
  end
end
