class AddStripeOrderIdToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :stripe_order_id, :string
  end
end
