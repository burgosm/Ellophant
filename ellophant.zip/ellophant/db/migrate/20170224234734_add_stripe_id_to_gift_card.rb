class AddStripeIdToGiftCard < ActiveRecord::Migration
  def change
    add_column :gift_cards, :stripe_id, :string
  end
end
