class AddDeletedToContacts < ActiveRecord::Migration
  def change
    add_column :contacts, :deleted, :boolean
  end
end
