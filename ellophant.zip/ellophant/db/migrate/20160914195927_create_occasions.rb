class CreateOccasions < ActiveRecord::Migration
  def change
    create_table :occasions do |t|
      t.string :name
      t.date :date
      t.integer :card_id
      t.text :message

      t.timestamps
    end
  end
end
