class AddIndexToContacts < ActiveRecord::Migration
  def change
    add_index :contacts, :deleted
  end
end
