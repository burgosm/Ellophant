class AddDefaultValueToDeleted < ActiveRecord::Migration
  def up
    change_column :contacts, :deleted, :boolean, :default => false
  end

  def down
    change_column :contacts, :deleted, :boolean, :default => nil
  end
end
