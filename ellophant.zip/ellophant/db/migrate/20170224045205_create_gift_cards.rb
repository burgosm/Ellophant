class CreateGiftCards < ActiveRecord::Migration
  def change
    create_table :gift_cards do |t|
      t.string :retailer
      t.integer :min
      t.integer :max
      t.integer :value
      t.string :stripe_sku

      t.timestamps
    end
  end
end
