class AddInteriorLeftToCards < ActiveRecord::Migration
  def self.up
    add_attachment :cards, :interior_left
  end

  def self.down
    remove_attachment :cards, :interior_left
  end
end
