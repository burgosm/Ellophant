class AddCardIdToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :card_id, :string
  end
end
