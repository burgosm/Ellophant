class AddIndexToCards < ActiveRecord::Migration
  def change
    add_index :cards, :card_id
  end
end
