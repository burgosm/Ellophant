class RemoveJobIdFromOccasions < ActiveRecord::Migration
  def change
    remove_column :occasions, :job_id, :integer
  end
end
