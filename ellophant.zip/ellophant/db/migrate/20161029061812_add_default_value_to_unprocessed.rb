class AddDefaultValueToUnprocessed < ActiveRecord::Migration
  def up
    change_column :occasions, :unprocessed, :boolean, :default => false
  end

  def down
    change_column :occasions, :unprocessed, :boolean, :default => nil
  end
end
