class RemoveCardIdFromOccasions < ActiveRecord::Migration
  def change
    remove_column :occasions, :card_id, :integer
  end
end
