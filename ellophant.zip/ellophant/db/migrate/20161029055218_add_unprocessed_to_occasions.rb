class AddUnprocessedToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :unprocessed, :boolean
  end
end
