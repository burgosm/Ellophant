class AddLast4ToCustomers < ActiveRecord::Migration
  def change
    add_column :customers, :last4, :string
  end
end
