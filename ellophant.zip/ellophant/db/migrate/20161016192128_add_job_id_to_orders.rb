class AddJobIdToOrders < ActiveRecord::Migration
  def change
    add_column :orders, :job_id, :integer
  end
end
