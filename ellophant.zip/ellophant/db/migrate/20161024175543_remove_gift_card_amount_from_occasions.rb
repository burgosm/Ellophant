class RemoveGiftCardAmountFromOccasions < ActiveRecord::Migration
  def change
    remove_column :occasions, :gift_card_amount, :integer
  end
end
