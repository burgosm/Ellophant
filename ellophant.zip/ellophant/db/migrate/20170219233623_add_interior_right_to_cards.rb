class AddInteriorRightToCards < ActiveRecord::Migration
  def self.up
    add_attachment :cards, :interior_right
  end

  def self.down
    remove_attachment :cards, :interior_right
  end
end
