class AddGiftCardProviderToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :gift_card_provider, :string
  end
end
