class AddUnprocessedReasonToOccasions < ActiveRecord::Migration
  def change
    add_column :occasions, :unprocessed_reason, :string
  end
end
